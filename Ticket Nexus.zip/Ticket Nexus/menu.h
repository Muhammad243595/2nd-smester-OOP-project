#include<iostream>


class Menu {
public:
	public:
	static void loginPage() {
		Color::setCyanTextColor();
		std::cout << "----------------------------------------------------\n";
		std::cout << "                     Main Menu                      \n";
		std::cout << "----------------------------------------------------\n\n";
		Color::resetTextColor();

		std::cout << "1. Login\n"
	              << "2. Sign Up\n"
	              << "3. Admin Panel\n"
				  << "4. Exit\n";
	              
	}

	static void DisplayMovieGenres(){
		Color::setCyanTextColor();
		std::cout << "\n=========== AVAILABLE GENRES ===========\n";
		Color::resetTextColor();

	    std::cout << " 1. Action          - High-paced, intense scenes\n";
	    std::cout << " 2. Adventure       - Exploration and thrilling journeys\n";
	    std::cout << " 3. Comedy          - Humorous and light-hearted content\n";
	    std::cout << " 4. Drama           - Emotionally rich and serious stories\n";
	    std::cout << " 5. Horror          - Scary and suspenseful experiences\n";
	    std::cout << " 6. Science Fiction - Futuristic or tech-driven worlds\n";
	    std::cout << " 7. Romance         - Love-focused storytelling\n";
	    std::cout << " 8. Thriller        - Suspenseful with plot twists\n";
	    std::cout << " 9. Animation       - Stylized, often family-friendly\n";
	    std::cout << "10. Fantasy         - Magical or mythical elements\n";
	    std::cout << "11. Mystery         - Solving puzzles or crimes\n";
	    std::cout << "12. Crime           - Criminal activities or investigations\n";
	    std::cout << "13. Musical         - Story with songs and dance\n";
	    std::cout << "14. Documentary     - Real-life or factual subjects\n";
	    std::cout << "15. Historical      - Based on past events\n";
	    std::cout << "16. War             - Military conflict settings\n";
	    std::cout << "17. Western         - Cowboy/frontier themes\n";
	    std::cout << "18. Biography       - Life of real individuals\n";

		Color::setCyanTextColor();
	    std::cout << "=========================================\n";
		Color::resetTextColor();
	}
	
	static void DisplayMovieDurations() {
		Color::setCyanTextColor();
		std::cout << "\n=========== MOVIE DURATIONS ===========\n";
		Color::resetTextColor();

		std::cout << " 1. Short Film     - Under 40 minutes\n";
		std::cout << " 2. Standard Film  - 90 to 120 minutes\n";
		std::cout << " 3. Extended Film  - 120 to 150 minutes\n";
		std::cout << " 4. Epic Feature   - Over 150 minutes\n";
		Color::setCyanTextColor();
		std::cout << "=======================================\n";
		Color::resetTextColor();
	}

	static void DisplayMovieRatings() {

		Color::setCyanTextColor();
		std::cout << "\n=============== MOVIE RATINGS ===============\n";
		Color::resetTextColor();

		std::cout << " 1. G       - General Audience (All Ages)\n";
		std::cout << " 2. PG      - Parental Guidance Suggested\n";
		std::cout << " 3. PG-13   - Parents Strongly Cautioned\n";
		std::cout << " 4. R       - Restricted (17+ with guardian)\n";
		std::cout << " 5. NC-17   - Adults Only (18 and above)\n";
		std::cout << " 6. U       - Universal (suitable for all)\n";
		std::cout << " 7. UA      - Under adult supervision\n";
		std::cout << " 8. A       - Adults only (strict)\n";
		std::cout << " 9. Not Rated - No official classification\n";

		Color::setCyanTextColor();
		std::cout << "=============================================\n";
		Color::resetTextColor();
	}

};

