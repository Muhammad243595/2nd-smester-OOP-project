#include <windows.h>

class Color {
    static HANDLE hConsole;
public:
    // Initialize the static member in the class definition
    static void initialize() {
        hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    }
    // ---------------------- Text Color Setters ----------------------
    static void setBlackTextColor()    { SetConsoleTextAttribute(hConsole, 0); }
    static void setRedTextColor()      { SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_INTENSITY); }
    static void setGreenTextColor()    { SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY); }
    static void setBlueTextColor()     { SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | FOREGROUND_INTENSITY); }
    static void setYellowTextColor()   { SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY); }
    static void setCyanTextColor()     { SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY); }
    static void setWhiteTextColor()    { SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY); }
    static void setGrayTextColor()     { SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE); }

    // ---------------------- Light Color Variants ----------------------
    static void setLightRedTextColor()     { SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_INTENSITY); }
    static void setLightGreenTextColor()   { SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY); }
    static void setLightBlueTextColor()    { SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | FOREGROUND_INTENSITY); }
    static void setLightYellowTextColor()  { SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY); }
    static void setLightCyanTextColor()    { SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY); }
    static void setLightMagentaTextColor() { SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_BLUE | FOREGROUND_INTENSITY); }
    static void setLightGrayTextColor()    { SetConsoleTextAttribute(hConsole, FOREGROUND_INTENSITY); }
    // ---------------------- Reset Colors ----------------------
    
	static void resetTextColor() {SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);}
};
HANDLE Color::hConsole = GetStdHandle(STD_OUTPUT_HANDLE);//static member of Color class