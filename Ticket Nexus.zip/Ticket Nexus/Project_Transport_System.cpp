#define NOMINMAX
#include "Validation.h"
#include "menu.h"
#include "wait.h"
#include "animation.h"

//Base Class
class Transport {
protected:
    int transportID;
    int totalSeats;
    bool* availableSeats;
    std::string type;
    float fare;

public:
    Transport() : transportID(0), totalSeats(0), availableSeats(nullptr), type(""), fare(0.0) {}

    //Destructor is Virtual so that it will be called in the dervived class as well.
    virtual ~Transport() {
        delete[] availableSeats;
        availableSeats = nullptr;
    }

    //Setters
    virtual bool setTransportID(const std::string&) = 0;
    virtual bool setTotalSeats(const std::string&) = 0;
    virtual void declareAvailableSeats(const int&) = 0;
    virtual bool bookAvailableSeat(const std::string&) = 0;
    virtual void saveTotalAvailableSeats() = 0;
    virtual void readTotalAvailableSeats() = 0;
    virtual bool setType(const std::string&) = 0;
    virtual bool setFare(const std::string&) = 0;
    //virtual void displayDetails() const = 0;

    int getTransportID() const { return transportID; }
    int getTotalSeats() const { return totalSeats; }
    bool getAvailableSeats(const int& i) const { return availableSeats[i]; }  // Be careful when returning raw pointers!
    std::string getType() const { return type; }
    float getFare() const { return fare; }
};

//Base Class
class Schedule {
protected:
    std::string departureCity, arrivalCity;
    std::string departureTime, arrivalTime;
    std::string departureDate, arrivalDate;
public:
    Schedule() : departureCity(""), arrivalCity(""), departureTime(""),
        arrivalTime(""), departureDate(""), arrivalDate("") {
    }

    virtual bool setDepartureCity(const std::string&) = 0;
    virtual bool setArrivalCity(const std::string&) = 0;
    virtual bool setDepartureDate(const std::string&) = 0;
    virtual bool setArrivalDate(const std::string&) = 0;
    virtual bool setDepartureTime(const std::string&) = 0;
    virtual bool setArrivalTime(const std::string&) = 0;

    std::string getDepartureCity() const { return departureCity; }
    std::string getArrivalCity() const { return arrivalCity; }
    std::string getArrivalDate() const { return arrivalDate; }

    std::string getDepartureDate() const { return departureDate; }
    std::string getDepartureTime() const { return departureTime; }
    std::string getArrivalTime() const { return arrivalTime; }
};

//Base Class
class TransportOperator {
protected:
    int transportOperatorID;
    std::string name;
    int age;
    std::string phoneNumber;
public:
    TransportOperator() : transportOperatorID(0), name(""), age(0), phoneNumber("") {}
    virtual ~TransportOperator() {}

    virtual bool setTransportOperatorID(const std::string&) = 0;
    virtual bool setTransportOperatorName(const std::string&) = 0;
    virtual bool setTransportOperatorAge(const std::string&) = 0;
    virtual bool setTransportOperatorPhoneNumber(const std::string&) = 0;

    int getTransportOperatorID() const { return transportOperatorID; }
    std::string getTransportOperatorName() const { return name; }
    int getTransportOperatorAge() const { return age; }
    std::string getTransportOperatorPhoneNumber() const { return phoneNumber; }
};

class PaymentDetails {
private:
    std::string name;
    std::string cardNumber;
    std::string expiryDate;
    std::string cvv;
    std::string nameOnCard;

public:

    bool setName(const std::string& temp) {
        if (!Validation::isValidName(temp, "Customer Name"))
            return false;

        name = temp;
        return true;

    }

    bool setCardNumber(const std::string& temp) {
        if (!Validation::isValidCardNumber(temp))
            return false;

        cardNumber = temp;
        return true;
    }

    bool setExpiryDate(const std::string& temp) {
        if (!Validation::isValidDateFormat(temp, "Expiry Date"))
            return false;

        expiryDate = temp;
        return true;
    }

    bool setCVV(const std::string& temp) {
        if (!Validation::isValidCVV(temp))
            return false;

        cvv = temp;
        return true;
    }

    bool setNameOnCard(const std::string& temp) {
        if (!Validation::isValidName(temp, "User name"))
            return false;

        nameOnCard = temp;
        return true;
    }

    // Getters

    std::string getName() 		const { return name; }
    std::string getCardNumber() const { return cardNumber; }
    std::string getExpiryDate() const { return expiryDate; }
    std::string getCVV() 		const { return cvv; }
    std::string getNameOnCard() const { return nameOnCard; }
};

class PaymentInputs {
private:
    PaymentDetails p;
    static std::string temp;
public:
    // Generic input helper taking a prompt and a pointer-to-member- setter function.
    static void inputGeneric(PaymentDetails& pay, const std::string& prompt, bool (PaymentDetails::* setter)(const std::string&)) {
        short int count = 0, max_tries = 5;
        while (true) {
            system("cls");
            Color::setCyanTextColor();
            std::cout << "----------------------------------------------------\n";
            std::cout << "                  Payment Details                   \n";
            std::cout << "----------------------------------------------------\n\n";
            Color::resetTextColor();
            std::cout << prompt;
            std::string input;
            getline(std::cin, input);
            if ((pay.*setter)(input)) {
                Print::Saved();
                break;
            }
            else {
                count++;
                if (count >= max_tries) {
                    pause(30);
                }
                system("pause");
            }
        }
    }

    void inputName() {
        inputGeneric(p, "Enter Name: ", &PaymentDetails::setName);
        std::cout << "Name: " << p.getName() << std::endl << std::endl;
        system("pause");
    }

    void inputCardNumber() {
        inputGeneric(p, "Enter Card Number: ", &PaymentDetails::setCardNumber);

        std::cout << "Card Number: " << p.getCardNumber() << std::endl << std::endl;

        system("pause");
    }

    void inputExpiryDate() {
        inputGeneric(p, "Enter Expiry Date (dd/mm/yyyy): ", &PaymentDetails::setExpiryDate);

        std::cout << "Expiry Date: " << p.getExpiryDate() << std::endl << std::endl;

        system("pause");
    }

    void inputCVV() {
        inputGeneric(p, "Enter CVV (Card Verification Value): ", &PaymentDetails::setCVV);

        std::cout << "CVV: " << p.getCVV() << std::endl << std::endl;

        system("pause");
    }

    void inputNameOnCard() {
        inputGeneric(p, "Enter Name on Card: ", &PaymentDetails::setNameOnCard);

        std::cout << "Name on Card: " << p.getNameOnCard() << "\n\n";

        system("pause");
    }

    bool savePaymentDataOnFile() {
        if (p.getName().empty()) {
            std::cout << "Name is missing.\n";
            return false;
        }
        else if (p.getNameOnCard().empty()) {
            std::cout << "Name on card is missing.\n";
            return false;
        }
        else if (p.getCardNumber().empty()) {
            std::cout << "Card number is missing.\n";
            return false;
        }
        else if (p.getExpiryDate().empty()) {
            std::cout << "Expiry date is missing.\n";
            return false;
        }
        else if (p.getCVV().empty()) {
            std::cout << "CVV is missing.\n";
            return false;
        }
        std::ofstream write("PaymentData.txt", std::ios::app);
        write << p.getName() << "|" << p.getCardNumber() << "|" << p.getExpiryDate() << "|"
            << p.getCVV() << "|" << p.getNameOnCard() << "\n";
        write.close();

        Print::Saved();
        return true;
    }

    PaymentDetails getPaymentDetails() {
        return p;
    }
};

class PaymentInterface {
public:
    static PaymentDetails makePayment() {
        PaymentInputs p_i;
        Color::setCyanTextColor();
        std::cout << "----------------------------------------------------\n";
        std::cout << "                  Ticket Payment                    \n";
        std::cout << "----------------------------------------------------\n\n";
        Color::resetTextColor();
        p_i.inputName();
        p_i.inputCardNumber();
        p_i.inputExpiryDate();
        p_i.inputNameOnCard();
        p_i.inputCVV();
        p_i.savePaymentDataOnFile();

        return p_i.getPaymentDetails();
    }
};

class Bus : public Transport, public TransportOperator, public Schedule {
private:
    std::string numberPlate;
public:
    Bus() : numberPlate("") {}

    bool setTransportID(const std::string& id) override {
        if (!Validation::isValidID(id, "Bus ID")) return false;

        else if (!Validation::isValidInteger(id, "Bus ID")) return false;

        else if (Validation::doesDataExistInBusFile(id, '1')) {
            Print::Error("Bus ID already Exists.");
            return false;
        }

        transportID = std::stoi(id);
        return true;
    }

    bool setNumberPlate(const std::string& plate) {
        if (!Validation::isValidNumberPlate(plate)) return false;

        else if (Validation::doesDataExistInBusFile(plate, '2')) {
            Print::Error("Number Plate already exists.");
            return false;
        }

        numberPlate = plate;
        return true;
    }

    bool setType(const std::string& busType) override {
        if (!Validation::isValidBusType(busType, "Bus Type")) return false;
        type = busType;
        return true;
    }

    void declareAvailableSeats(const int& totalSeats) override {
        delete[] availableSeats;
        availableSeats = new bool[totalSeats];
        std::fill(availableSeats, availableSeats + totalSeats, true);
    }

    bool bookAvailableSeat(const std::string& seat) override {
        if (!Validation::isValidBusSeatAccordingToType(seat, "Bus Seat", type)) return false;

        else if (!Validation::isValidInteger(seat, "Bus Seat")) return false;

        int Seat = std::stoi(seat);
        if (Seat < 1 || Seat > totalSeats) {
            Print::Error("Invalid Seat Number");
            return false;
        }
        if (!availableSeats[Seat]) {
            Print::Error("Seat already booked.");
            return false;
        }
        availableSeats[Seat] = 0;   //False 0 = Booked
        return true;
    }

    bool setTotalSeats(const std::string& seats) override {
        if (!Validation::isValidSeatNumber(seats, "Bus Seats")) return false;

        else if (!Validation::isValidInteger(seats, "Bus Seats")) return false;

        else if (!Validation::isValidBusSeatAccordingToType(seats, "Bus Seats", type)) return false;

        else {
            totalSeats = std::stoi(seats);
            declareAvailableSeats(totalSeats);
            return true;
        }
    }

    void saveTotalAvailableSeats() override {
        std::string fileName = "Bus_" + std::to_string(transportID) + "_Seats.txt";
        std::ofstream write(fileName);
        if (!write) {
            Color::setRedTextColor();
            std::cout << "Error Opening " << fileName << " File.\n\n";
            Color::resetTextColor();
            return;
        }
        for (int i = 0; i < totalSeats; i++) {
            if (getAvailableSeats(i)) {
                write << "1\n";
            }
            else
                write << "0\n";
        }
    }

    void readTotalAvailableSeats() override {
        std::string fileName = "Bus_" + std::to_string(transportID) + "_Seats.txt";
        std::ifstream read(fileName);
        if (!read) {
            Color::setRedTextColor();
            std::cout << "Error Opening " << fileName << " File.\n\n";
            Color::resetTextColor();
            return;
        }
        int status, availablecount = 0;
        while (read >> status) {
            switch (status) {
            case 1: {
                availablecount++;
            }
            }
        }
        std::cout << "Available Seats in Bus " << transportID << ": " << availablecount << std::endl;
    }

    bool setFare(const std::string& price) override {
        if (!Validation::isValidBusPriceAccordingToType(price, "Bus Fare", type)) return false;
        fare = std::stof(price);
        return true;
    }

    bool setDepartureCity(const std::string& city) override {
        if (!Validation::isValidCity(city, "Departure City")) return false;
        departureCity = city;
        return true;
    }

    bool setArrivalCity(const std::string& city) override {
        if (!Validation::isValidCity(city, "Arrival City")) return false;
        arrivalCity = city;
        return true;
    }

    bool setDepartureDate(const std::string& date) override {
        if (!Validation::isValidDate(date, "Departure Date")) return false;
        departureDate = date;
        return true;
    }

    bool setArrivalDate(const std::string& date) override {
        if (!Validation::isValidArrivalDate(date, departureDate)) return false;
        arrivalDate = date;
        return true;
    }

    bool setDepartureTime(const std::string& time) override {
        if (!Validation::isValidTime(time, departureDate, "Departure Time")) return false;
        departureTime = time;
        return true;
    }

    bool setArrivalTime(const std::string& time) override {
        if (!Validation::isValidArrivalTime(time, departureTime, arrivalDate, departureDate)) return false;
        arrivalTime = time;
        return true;
    }
    //virtual void displayDetails() const = 0;

    //Driver ID
    bool setTransportOperatorID(const std::string& ID) override {
        if (!Validation::isValidID(ID, "Driver")) return false;

        else if (Validation::doesDataExistInBusFile(ID, '3')) {
            Print::Error("Driver ID already Exists.");
            return false;
        }

        transportOperatorID = std::stoi(ID);
        return true;
    }

    //Driver Name
    bool setTransportOperatorName(const std::string& temp) override {
        if (!Validation::isValidName(temp, "Driver Name")) return false;
        name = temp;
        return true;
    }

    bool setTransportOperatorAge(const std::string& temp) override {
        if (!Validation::isValidAge(temp)) return false;
        age = std::stoi(temp);
        return true;
    }

    bool setTransportOperatorPhoneNumber(const std::string& number) override {
        if (!Validation::isValidPhoneNumber(number, "Driver's Phone Number")) return false;
        phoneNumber = number;
        return true;
    }

    std::string getNumberPlate() const { return numberPlate; }
};

class BusDetailsInput {
public:
    BusDetailsInput() {
    }

    // Generic input helper taking a prompt and a pointer-to-member- setter function.
    static void inputGeneric(Bus& b, const std::string& prompt, bool (Bus::* setter)(const std::string&)) {
        short int count = 0, max_tries = 5;
        while (true) {
            std::cout << prompt;
            std::string input;
            getline(std::cin, input);
            if ((b.*setter)(input)) {
                Print::Saved();
                break;
            }
            else {
                count++;
                if (count >= max_tries) {
                    pause(30);
                }
            }
        }
    }

    // Now redefine your calls using inputGeneric

    static void inputBusID(Bus& b) {
        inputGeneric(b, "Enter Bus ID: ", &Bus::setTransportID);
    }

    static void inputBusNumberPlate(Bus& b) {
        inputGeneric(b, "Enter Bus Number Plate: ", &Bus::setNumberPlate);
    }

    static void inputBusTotalSeats(Bus& b) {
        inputGeneric(b, "Enter Bus Total Seats: ", &Bus::setTotalSeats);
    }

    static void bookSeat(Bus& b) {
        inputGeneric(b, "Enter Seat Number to Book: ", &Bus::bookAvailableSeat);
    }

    static void inputBusType(Bus& b) {
        std::cout << "Bus Types: Economy, Business, Executive, Sleeper, VIP.\n";
        inputGeneric(b, "Enter Bus Type: ", &Bus::setType);
    }

    static void inputBusFare(Bus& b) {
        inputGeneric(b, "Enter Bus Fare: $", &Bus::setFare);
    }

    // For Bus Driver data:
    static void inputBusDriverID(Bus& b) {
        inputGeneric(b, "Enter Bus Driver's ID: ", &Bus::setTransportOperatorID);
    }

    static void inputBusDriverName(Bus& b) {
        inputGeneric(b, "Enter Bus Driver's Name: ", &Bus::setTransportOperatorName);
    }

    static void inputBusDriverNumber(Bus& b) {
        inputGeneric(b, "Enter Bus Driver's Phone Number: ", &Bus::setTransportOperatorPhoneNumber);
    }

    static void inputBusDriverAge(Bus& b) {
        inputGeneric(b, "Enter Bus Driver's Age: ", &Bus::setTransportOperatorAge);
    }

    // For Departure/Arrival info:
    static void inputBusDepartureCity(Bus& b) {
        inputGeneric(b, "Enter Bus's Departure City: ", &Bus::setDepartureCity);
    }

    static void inputBusDepartureTime(Bus& b) {
        inputGeneric(b, "Enter Bus's Departure Time: ", &Bus::setDepartureTime);
    }

    static void inputBusDepartureDate(Bus& b) {
        inputGeneric(b, "Enter Bus's Departure Date: ", &Bus::setDepartureDate);
    }

    static void inputBusArrivalCity(Bus& b) {
        inputGeneric(b, "Enter Bus's Arrival City: ", &Bus::setArrivalCity);
    }

    static void inputBusArrivalTime(Bus& b) {
        inputGeneric(b, "Enter Bus's Arrival Time: ", &Bus::setArrivalTime);
    }

    static void inputBusArrivalDate(Bus& b) {
        inputGeneric(b, "Enter Bus's Arrival Date: ", &Bus::setArrivalDate);
    }
};

class BusFile {
public:
    static void saveBusDataOnFile(const Bus& b) {
        std::ofstream write("Bus_Data.txt", std::ios::app);
        if (write.fail()) {
            Print::Error("Unable to open Bus_Data.");
            return;
        }
        /*
        Saving Format
        0.Bus ID(int) 1.Number Plate(string) 2.Type(string) 3.Total Seat(int) 4.Fare(float)
        5.Driver ID(int) 6.Driver Name(string) 7.Driver Age(int) 8. Driver Phone Number(string)
        9.Departure City(string) 10.Departure Date(string) 11.Departure Time(string)
        12.Arrival City(string) 13. Arrival Date(string) 14. Arrival Time(string)
        */
        write << b.getTransportID() << "|" << b.getNumberPlate() << "|" << b.getType() << "|" << b.getTotalSeats() << "|" << b.getFare() << "|"
            << b.getTransportOperatorID() << "|" << b.getTransportOperatorName() << "|" << b.getTransportOperatorAge() << "|" << b.getTransportOperatorPhoneNumber() << "|"
            << b.getDepartureCity() << "|" << b.getDepartureDate() << "|" << b.getDepartureTime() << "|"
            << b.getArrivalCity() << "|" << b.getArrivalDate() << "|" << b.getArrivalTime() << std::endl;
        write.close();
    }
};

class TransportDetailsDisplay {
public:
    // Constructor
    TransportDetailsDisplay() {}

    // Function to display all bus details
    static void displayBusDetailsForAdmin(const BusRecord& record) {
        Color::setCyanTextColor();
        std::cout << "------------------- Bus Details --------------------\n";
        Color::resetTextColor();
        /*
        Saving Format
        0.Bus ID(int) 1.Number Plate(string) 2.Type(string) 3.Total Seat(int) 4.Fare(float)
        5.Driver ID(int) 6.Driver Name(string) 7.Driver Age(int) 8. Driver Phone Number(string)
        9.Departure City(string) 10.Departure Date(string) 11.Departure Time(string)
        12.Arrival City(string) 13. Arrival Date(string) 14. Arrival Time(string)
        */
        std::cout << "Bus ID: " << record.busID << "\n";
        std::cout << "Number Plate: " << record.numberPlate << "\n";
        std::cout << "Bus Type: " << record.type << "\n";
        std::cout << "Total Seats: " << record.totalSeat << "\n";
        std::cout << "Available Seats: " << record.numberOfAvailableSeats << "\n";
        std::cout << "Fare: " << record.fare << "\n\n";

        std::cout << "Driver ID: " << record.driverID << "\n";
        std::cout << "Driver Name: " << record.driverName << "\n";
        std::cout << "Driver Age: " << record.driverAge << "\n";
        std::cout << "Driver Phone Number: " << record.driverPhoneNumber << "\n\n";

        std::cout << "Departure City: " << record.departureCity << "\n";
        std::cout << "Departure Date: " << record.departureDate << "\n";
        std::cout << "Departure Time: " << record.departureTime << "\n\n";
        std::cout << "Arrival City: " << record.arrivalCity << "\n";
        std::cout << "Arrival Date: " << record.arrivalDate << "\n";
        std::cout << "Arrival Time: " << record.arrivalTime << "\n";

        Color::setCyanTextColor();
        std::cout << "-----------------------------------------------------\n";
        Color::resetTextColor();
    }

    static void displayBusDetailsForUser(const BusRecord& record) {

        Color::setCyanTextColor();
        std::cout << "------------------- Bus Details --------------------\n";
        Color::resetTextColor();

        std::cout << "Bus ID: " << record.busID << "\n";
        std::cout << "Number Plate: " << record.numberPlate << "\n";
        std::cout << "Bus Type: " << record.type << "\n";
        std::cout << "Fare: " << record.fare << "\n";
        std::cout << "Available Seats: " << record.numberOfAvailableSeats << "\n\n";

        std::cout << "Route: " << record.departureCity << " to " << record.arrivalCity << "\n";
        std::cout << "Departure: " << record.departureDate << " " << record.departureTime << "\n";
        std::cout << "Arrival: " << record.arrivalDate << " " << record.arrivalTime << "\n";

        Color::setCyanTextColor();
        std::cout << "-----------------------------------------------------\n";
        Color::resetTextColor();
    }
};

class adminBusFunctionality {
public:
    static void addBus() {
        Color::setCyanTextColor();
        std::cout << "----------------------------------------------------\n";
        std::cout << "                  Add Bus Interface                 \n";
        std::cout << "----------------------------------------------------\n\n";
        Color::resetTextColor();
        Bus b;
        BusDetailsInput::inputBusID(b);
        BusDetailsInput::inputBusNumberPlate(b);
        BusDetailsInput::inputBusType(b);
        BusDetailsInput::inputBusTotalSeats(b);
        BusDetailsInput::inputBusFare(b);
        BusDetailsInput::inputBusDriverID(b);
        BusDetailsInput::inputBusDriverName(b);
        BusDetailsInput::inputBusDriverAge(b);
        BusDetailsInput::inputBusDriverNumber(b);
        BusDetailsInput::inputBusDepartureCity(b);
        BusDetailsInput::inputBusDepartureDate(b);
        BusDetailsInput::inputBusDepartureTime(b);
        BusDetailsInput::inputBusArrivalCity(b);
        BusDetailsInput::inputBusArrivalDate(b);
        BusDetailsInput::inputBusArrivalTime(b);
        BusFile::saveBusDataOnFile(b);
        b.saveTotalAvailableSeats();
        return;
    }

    static void viewBuses() {
        std::ifstream read("Bus_Data.txt");

        if (read.fail()) {
            Print::Error("Bus_Data File Not Found.");
            return;
        }

        if (Validation::isFileEmpty(read, "Bus_Data")) {
            return;
        }
        std::string line = "";
        /*
        Saving Format
        0.Bus ID(int) 1.Number Plate(string) 2.Type(string) 3.Total Seat(int) 4.Fare(float)
        5.Driver ID(int) 6.Driver Name(string) 7.Driver Age(int) 8. Driver Phone Number(string)
        9.Departure City(string) 10.Departure Date(string) 11.Departure Time(string)
        12.Arrival City(string) 13. Arrival Date(string) 14. Arrival Time(string)
        */
        while (getline(read, line)) {
            BusRecord record;
            std::istringstream in(line);
            getline(in, record.busID, '|');
            getline(in, record.numberPlate, '|');
            getline(in, record.type, '|');
            getline(in, record.totalSeat, '|');
            getline(in, record.fare, '|');

            getline(in, record.driverID, '|');
            getline(in, record.driverName, '|');
            getline(in, record.driverAge, '|');
            getline(in, record.driverPhoneNumber, '|');

            getline(in, record.departureCity, '|');
            getline(in, record.departureDate, '|');
            getline(in, record.departureTime, '|');

            getline(in, record.arrivalCity, '|');
            getline(in, record.arrivalDate, '|');
            getline(in, record.arrivalTime);
            std::ifstream readAvailableSeats("Bus_" + record.busID + "_Seats.txt");
            if (!readAvailableSeats.fail()) {
                bool status = false;
                while (readAvailableSeats >> status)
                    if (status)
                        record.numberOfAvailableSeats++;

            }
            TransportDetailsDisplay::displayBusDetailsForAdmin(record);
        }
        read.close();
        return;
    }

    static bool searchBus(const std::string& ID) {
        if (!Validation::isValidID(ID, "Bus")) {
            return false;
        }
        int busID = std::stoi(ID);
        std::ifstream read("Bus_Data.txt");

        if (!read) {
            Color::setRedTextColor();
            std::cout << "Error: Bus_Data File Not Found.\n\n";
            Color::resetTextColor();
            return false;
        }
        if (Validation::isFileEmpty(read, "Bus_Data")) {
            return false;
        }
        bool notFound = true;
        BusRecord record;
        std::string line = "";
        system("cls");
        Color::setCyanTextColor();
        std::cout << "----------------------------------------------------\n";
        std::cout << "                Search Bus Interface                \n";
        std::cout << "----------------------------------------------------\n\n";
        Color::resetTextColor();
        /*
        Saving Format
        0.Bus ID(int) 1.Number Plate(string) 2.Type(string) 3.Total Seat(int) 4.Fare(float)
        5.Driver ID(int) 6.Driver Name(string) 7.Driver Age(int) 8. Driver Phone Number(string)
        9.Departure City(string) 10.Departure Date(string) 11.Departure Time(string)
        12.Arrival City(string) 13. Arrival Date(string) 14. Arrival Time(string)
        */
        while (getline(read, line)) {
            std::istringstream in(line);
            getline(in, record.busID, '|');
            getline(in, record.numberPlate, '|');
            getline(in, record.type, '|');
            getline(in, record.totalSeat, '|');
            getline(in, record.fare, '|');

            getline(in, record.driverID, '|');
            getline(in, record.driverName, '|');
            getline(in, record.driverAge, '|');
            getline(in, record.driverPhoneNumber, '|');

            getline(in, record.departureCity, '|');
            getline(in, record.departureDate, '|');
            getline(in, record.departureTime, '|');

            getline(in, record.arrivalCity, '|');
            getline(in, record.arrivalDate, '|');
            getline(in, record.arrivalTime);

            if (std::stoi(record.busID) == busID) {
                std::ifstream readAvailableSeats("Bus_" + record.busID + "_Seats.txt");
                if (!readAvailableSeats.fail()) {
                    bool status = false;
                    while (readAvailableSeats >> status)
                        if (status)
                            record.numberOfAvailableSeats++;

                }
                notFound = false;
                TransportDetailsDisplay::displayBusDetailsForAdmin(record);
            }
        }
        read.close();
        if (notFound) {
            Print::Error("Bus Not Found.");
            return false;
        }
        system("pause");
        return true;
    }

    static bool deleteBus(const std::string& ID) {
        if (!Validation::isValidID(ID, "Bus")) {
            return false;
        }
        int busID = std::stoi(ID);
        std::ifstream read("Bus_Data.txt");

        if (!read) {
            Print::Error("Bus_Data File Not Found.");
            return false;
        }
        if (Validation::isFileEmpty(read, "Bus_Data")) {
            return false;
        }
        bool notFound = true;
        std::ofstream write("temp.txt");
        BusRecord record;
        std::string line = "";
        /*
        Saving Format
        0.Bus ID(int) 1.Number Plate(string) 2.Type(string) 3.Total Seat(int) 4.Fare(float)
        5.Driver ID(int) 6.Driver Name(string) 7.Driver Age(int) 8. Driver Phone Number(string)
        9.Departure City(string) 10.Departure Date(string) 11.Departure Time(string)
        12.Arrival City(string) 13. Arrival Date(string) 14. Arrival Time(string)
        */
        while (getline(read, line)) {
            std::istringstream in(line);
            getline(in, record.busID, '|');
            getline(in, record.numberPlate, '|');
            getline(in, record.type, '|');
            getline(in, record.totalSeat, '|');
            getline(in, record.fare, '|');

            getline(in, record.driverID, '|');
            getline(in, record.driverName, '|');
            getline(in, record.driverAge, '|');
            getline(in, record.driverPhoneNumber, '|');

            getline(in, record.departureCity, '|');
            getline(in, record.departureDate, '|');
            getline(in, record.departureTime, '|');

            getline(in, record.arrivalCity, '|');
            getline(in, record.arrivalDate, '|');
            getline(in, record.arrivalTime);
            if (std::stoi(record.busID) == busID) {
                notFound = false;
                continue;
            }
            write << record.busID << "|" << record.numberPlate << "|" << record.type << "|" << record.totalSeat << "|" << record.fare << "|"
                << record.driverID << "|" << record.driverName << "|" << record.driverAge << "|" << record.driverPhoneNumber << "|"
                << record.departureCity << "|" << record.departureDate << "|" << record.departureTime << "|"
                << record.arrivalCity << "|" << record.arrivalDate << "|" << record.arrivalTime << std::endl;
        }
        read.close();
        write.close();
        remove("Bus_Data.txt");
        std::string availableSeatsFile = "Bus_" + std::to_string(busID) + "_Seats.txt";
        remove(availableSeatsFile.c_str());
        if (rename("temp.txt", "Bus_Data.txt") != 0) {
            Print::Error("Unable to Rename File.");
            return false;
        }
        if (notFound) {
            Print::Error("Bus Not Found");
            return false;
        }
        else {
            Print::Success("Bus Data Deleted Successfully.");
            return true;
        }
        return true;
    }

    static void editBusDataOnFile(const int& busID, const std::string& choice, const std::string& prompt) {
        std::ifstream read("Bus_Data.txt");
        std::ofstream write("temp.txt");
        if (read.fail()) {
            Print::Error("Unable to open Bus_Data File.");
            return;
        }
        if (write.fail()) {
            Print::Error("Unable to open temporary File.");
            return;
        }
        if (Validation::isFileEmpty(read, "Bus_Data")) {
            return;
        }

        std::string input = "";
        while (true) {
            system("cls");
            input = "\0";

            Color::setCyanTextColor();
            std::cout << "----------------------------------------------------\n";
            std::cout << "                 Edit Bus Interface                 \n";
            std::cout << "----------------------------------------------------\n\n";
            Color::resetTextColor();

            std::cout << "Enter New " << prompt << ": ";
            getline(std::cin, input);
            if (choice == "1") {            //Bus Number Plate
                if (Validation::isValidNumberPlate(input)) {
                    break;
                }
            }
            else if (choice == "2") {       //Bus Type
                if (Validation::isValidBusType(input, "Bus Type")) {
                    break;
                }
            }
            else if (choice == "3") {       //Bus Seats
                if (Validation::isValidSeatNumber(input, "Bus Seat")) {
                    break;
                }
            }
            else if (choice == "4") {       //Bus Fare
                if (Validation::isValidPrice(input, "Bus Fare")) {
                    break;
                }
                else {
                    Print::Error("Choose from : Economy, Business, Executive, Sleeper, VIP.");
                }
            }
            else if (choice == "5") {       //Driver Name
                if (Validation::isValidName(input, "Driver Name")) {
                    break;
                }
            }
            else if (choice == "6") {       //Driver Age
                if (Validation::isValidAge(input)) {
                    break;
                }
            }
            else if (choice == "7") {       //Driver Phone Number
                if (Validation::isValidPhoneNumber(input, "Driver's Phone Number")) {
                    break;
                }
            }
            else if (choice == "8") {       //Departure City
                if (Validation::isValidCity(input, "Departure City")) {
                    break;
                }
            }
            else if (choice == "9") {       //Departure Time
                if (Validation::isValidTimeFormat(input, "Departure Time")) {
                    break;
                }
            }
            else if (choice == "10") {      //Departure Date
                if (Validation::isValidDate(input, "Departure Date")) {
                    break;
                }
            }
            else if (choice == "11") {      //Arrival City
                if (Validation::isValidCity(input, "Arrival City")) {
                    break;
                }
            }
            else if (choice == "12") {      //Arrival Time
                if (Validation::isValidTimeFormat(input, "Arrival Time")) {
                    break;
                }
            }
            else if (choice == "13") {      //Arrival Date
                if (Validation::isValidDate(input, "Arrival Date")) {
                    break;
                }
            }
            Color::setLightYellowTextColor();
            std::cout << "\nRe-enter " << prompt << "? " << std::endl;
            Color::resetTextColor();
            std::cout << "Enter Yes or No (No as Default): ";
            getline(std::cin, input);
            if (input != "Yes" && input != "yes") {
                return;
            }
        }
        BusRecord record;
        bool success = false;
        std::string line = "";
        /*
        Saving Format
        0.Bus ID(int) 1.Number Plate(string) 2.Type(string) 3.Total Seat(int) 4.Fare(float)
        5.Driver ID(int) 6.Driver Name(string) 7.Driver Age(int) 8. Driver Phone Number(string)
        9.Departure City(string) 10.Departure Date(string) 11.Departure Time(string)
        12.Arrival City(string) 13. Arrival Date(string) 14. Arrival Time(string)
        */
        while (getline(read, line)) {
            std::istringstream in(line);
            getline(in, record.busID, '|');
            getline(in, record.numberPlate, '|');
            getline(in, record.type, '|');
            getline(in, record.totalSeat, '|');
            getline(in, record.fare, '|');

            getline(in, record.driverID, '|');
            getline(in, record.driverName, '|');
            getline(in, record.driverAge, '|');
            getline(in, record.driverPhoneNumber, '|');

            getline(in, record.departureCity, '|');
            getline(in, record.departureDate, '|');
            getline(in, record.departureTime, '|');

            getline(in, record.arrivalCity, '|');
            getline(in, record.arrivalDate, '|');
            getline(in, record.arrivalTime);
            if (std::stoi(record.busID) == busID) {
                if (choice == "1") {        //Number Plate
                    record.numberPlate = input;
                    success = true;
                }
                else if (choice == "2") {   //Type
                    record.totalSeat = input;
                    success = true;
                }
                else if (choice == "3") {   //Bus Total Seats
                    if (Validation::isValidBusSeatAccordingToType(input, "Bus Seats", record.type)) {  //(Seat, Prompt, Type)
                        Validation::redefineBusSeatFile(record.busID, input);
                        record.totalSeat = input;
                        success = true;
                    }
                    else
                        break;
                }
                else if (choice == "4") {   //Bus Fare
                    if (Validation::isValidBusPriceAccordingToType(input, "Bus Seat Fare", record.type)) {
                        record.fare = input;
                        success = true;
                    }
                }
                else if (choice == "5") {   //Driver Name
                    record.driverName = input;
                    success = true;
                }
                else if (choice == "6") {   //Driver Age
                    record.driverAge = input;
                    success = true;
                }
                else if (choice == "7") {   //Driver Phone Number
                    record.driverPhoneNumber = input;
                    success = true;
                }
                else if (choice == "8") {   //Departure City
                    record.departureCity = input;
                    success = true;
                }
                else if (choice == "9") {   //Departure Time
                    record.departureTime = input;
                    success = true;
                }
                else if (choice == "10") {  //Departure Date
                    record.departureDate = input;
                    success = true;
                }
                else if (choice == "11") {  //Arrival City
                    record.arrivalCity = input;
                    success = true;
                }
                else if (choice == "12") {  //Arrival Time
                    if (!Validation::isValidArrivalTime(input, record.departureTime, record.arrivalDate, record.departureDate)) {
                        success = false;
                    }
                    else {
                        record.arrivalTime = input;
                        success = true;
                    }
                }
                else if (choice == "13") {  //Arrival Date
                    if (!Validation::isValidArrivalDate(input, record.departureDate)) {
                        success = false;
                    }
                    else {
                        if (input == record.departureDate) {
                            Print::Warning("Please change Arrival Time as well.");
                        }
                        record.arrivalDate = input;
                        success = true;
                    }
                }
            }
            /*
            Saving Format
            0.Bus ID(int) 1.Number Plate(string) 2.Type(string) 3.Total Seat(int) 4.Fare(float)
            5.Driver ID(int) 6.Driver Name(string) 7.Driver Age(int) 8. Driver Phone Number(string)
            9.Departure City(string) 10.Departure Date(string) 11.Departure Time(string)
            12.Arrival City(string) 13. Arrival Date(string) 14. Arrival Time(string)
            */
            write << record.busID << "|" << record.numberPlate << "|" << record.type << "|" << record.totalSeat << "|" << record.fare << "|"
                << record.driverID << "|" << record.driverName << "|" << record.driverAge << "|" << record.driverPhoneNumber << "|"
                << record.departureCity << "|" << record.departureDate << "|" << record.departureTime << "|"
                << record.arrivalCity << "|" << record.arrivalDate << "|" << record.arrivalTime << std::endl;
        }
        write.close();
        read.close();
        remove("Bus_Data.txt");
        if (rename("temp.txt", "Bus_Data.txt") != 0) {
            Print::Error("Unable to Rename File");
            return;
        }
        if (success) {
            Print::Success("Saved in file.");
            return;
        }
        else {
            Print::Error("Unable to change " + prompt + ".");
            return;
        }

    }

    static bool editBus(const std::string& ID) {
        if (!Validation::isValidID(ID, "Bus ID")) {
            return false;
        }
        else if (!Validation::doesDataExistInBusFile(ID, '1')) {
            Print::Error("Bus ID doesn't exist.");
            return false;
        }
        else {
            int busID = std::stoi(ID);
            while (true) {
                system("cls");
                std::string choice = "\0";
                Color::setCyanTextColor();
                std::cout << "----------------------------------------------------\n";
                std::cout << "                 Edit Bus Interface                 \n";
                std::cout << "----------------------------------------------------\n\n";
                
                std::cout << "Edit Options\n\n";
                Color::resetTextColor();
                std::cout << "1. Number Plate" << std::endl;
                std::cout << "2. Type" << std::endl;
                std::cout << "3. Total Seats" << std::endl;
                std::cout << "4. Bus Fare" << std::endl;
                std::cout << "5. Driver Name" << std::endl;
                std::cout << "6. Driver Age" << std::endl;
                std::cout << "7. Driver Phone Number" << std::endl;
                std::cout << "8. Departure City" << std::endl;
                std::cout << "9. Departure Time" << std::endl;
                std::cout << "10. Departure Date" << std::endl;
                std::cout << "11. Arrival City" << std::endl;
                std::cout << "12. Arrival Time" << std::endl;
                std::cout << "13. Arrival Date" << std::endl;
                std::cout << "14. Exit" << std::endl;
                std::cout << "\nEnter your choice: ";
                getline(std::cin, choice);
                if (choice == "1") {
                    //Number Plate
                    system("cls");
                    editBusDataOnFile(busID, choice, "Number Plate");
                    system("pause");
                }
                else if (choice == "2") {
                    //Type
                    system("cls");
                    editBusDataOnFile(busID, choice, "Bus Type");
                    system("pause");
                }
                else if (choice == "3") {
                    //Total Seats
                    system("cls");
                    editBusDataOnFile(busID, choice, "Total Seats");
                    system("pause");
                }
                else if (choice == "4") {
                    //Bus Fare
                    system("cls");
                    editBusDataOnFile(busID, choice, "Bus Fare");
                    system("pause");
                }
                else if (choice == "5") {
                    //Driver Name
                    system("cls");
                    editBusDataOnFile(busID, choice, "Driver Name");
                    system("pause");
                }
                else if (choice == "6") {
                    //Driver Age
                    system("cls");
                    editBusDataOnFile(busID, choice, "Driver Age");
                    system("pause");
                }
                else if (choice == "7") {
                    //Driver Phone Number
                    system("cls");
                    editBusDataOnFile(busID, choice, "Driver Phone Number");
                    system("pause");
                }
                else if (choice == "8") {
                    //Departure City
                    system("cls");
                    editBusDataOnFile(busID, choice, "Departure City");
                    system("pause");
                }
                else if (choice == "9") {
                    //Departure Time
                    system("cls");
                    editBusDataOnFile(busID, choice, "Departure Time");
                    system("pause");
                }
                else if (choice == "10") {
                    //Departure Date
                    system("cls");
                    editBusDataOnFile(busID, choice, "Departure Date");
                    system("pause");
                }
                else if (choice == "11") {
                    //Arrival City
                    system("cls");
                    editBusDataOnFile(busID, choice, "Arrival City");
                    system("pause");
                }
                else if (choice == "12") {
                    //Arrival Time
                    system("cls");
                    editBusDataOnFile(busID, choice, "Arrival Time");
                    system("pause");
                }
                else if (choice == "13") {
                    //Arrival Date
                    system("cls");
                    editBusDataOnFile(busID, choice, "Arrival Date");
                    system("pause");
                }
                else if (choice == "14") {
                    Color::setLightMagentaTextColor();
                    std::cout << "\nExiting Bus Edit Menu....\n\n";
                    Color::resetTextColor();
                    break;
                }
                else {
                    Print::Error("Invalid Choice!");
                    system("pause");
                }
            }
        }
        return true;
    }

    static void viewAllBookingHistory() {
        std::ifstream bookingIn("Bus_Booking.txt");
        if (!bookingIn) {
            Print::Error("No booking records found.");
            return;
        }

        Color::setCyanTextColor();
        std::cout << "----------------------------------------------------\n";
        std::cout << "                 Bus Ticket History                 \n";
        std::cout << "----------------------------------------------------\n\n";
        Color::resetTextColor();

        std::string line;
        BusTicketRecord tr;
        /*
            Ticket Saving Format
            0. Username 1. Bus ID           2. Seat Number      3. Fare
            4. Departure City   5. Departure Date   6. Departure Time
            7. Arrival City     8. Arrival Date     9. Arrival Time
            10. Booking Time
        */
        while (getline(bookingIn, line)) {
            std::istringstream in(line);
            getline(in, tr.username, '|');
            getline(in, tr.busID, '|');
            getline(in, tr.seatNumber, '|');
            getline(in, tr.fare, '|');

            getline(in, tr.departureCity, '|');
            getline(in, tr.departureDate, '|');
            getline(in, tr.departureTime, '|');

            getline(in, tr.arrivalCity, '|');
            getline(in, tr.arrivalDate, '|');
            getline(in, tr.arrivalTime, '|');

            getline(in, tr.bookingTime);

            Color::setCyanTextColor();
            std::cout << "------------------- Bus Ticket ---------------------\n\n";
            Color::resetTextColor();

            std::cout << "Username: " << tr.username << "\n";
            std::cout << "Bus ID: " << tr.busID << "\n";
            std::cout << "Seat Number: " << tr.seatNumber << "\n";
            std::cout << "Seat Fare: " << tr.fare << "\n";
            std::cout << "Route: " << tr.departureCity << " to " << tr.arrivalCity << "\n";
            std::cout << "Departure Date: " << tr.departureDate << "\n";
            std::cout << "Departure Time: " << tr.departureTime << "\n";
            std::cout << "Arrival Date: " << tr.arrivalDate << "\n";
            std::cout << "Arrival Time: " << tr.arrivalTime << "\n";
            std::cout << "Booking Time: " << tr.bookingTime << "\n";

            Color::setCyanTextColor();
            std::cout << "----------------------------------------------------\n";
            Color::resetTextColor();
        }
        bookingIn.close();
        return;
    }

    static bool viewBookingHistoryOfAUser(const std::string& temp) {
        if (!Validation::isValidUsername(temp)) return false;

        std::string userName = Validation::getUsernameFromFile(temp);

        if (userName == "") {
            Print::Error("Username doesn't exist.");
            return false;
        }

        std::ifstream bookingIn("Bus_Booking.txt");
        if (!bookingIn) {
            Print::Error("No booking records found.");
            return false;
        }
        system("cls");
        Color::setCyanTextColor();
        std::cout << "----------------------------------------------------\n";
        std::cout << "                  Booking History                   \n";
        std::cout << "----------------------------------------------------\n\n";
        Color::resetTextColor();

        std::string line;
        BusTicketRecord tr;
        bool found = false;
        /*
            Ticket Saving Format
            0. Username 1. Bus ID           2. Seat Number      3. Fare
            4. Departure City   5. Departure Date   6. Departure Time
            7. Arrival City     8. Arrival Date     9. Arrival Time
            10. Booking Time
        */
        while (getline(bookingIn, line)) {
            std::istringstream in(line);
            getline(in, tr.username, '|');
            getline(in, tr.busID, '|');
            getline(in, tr.seatNumber, '|');
            getline(in, tr.fare, '|');

            getline(in, tr.departureCity, '|');
            getline(in, tr.departureDate, '|');
            getline(in, tr.departureTime, '|');

            getline(in, tr.arrivalCity, '|');
            getline(in, tr.arrivalDate, '|');
            getline(in, tr.arrivalTime, '|');

            getline(in, tr.bookingTime);

            if (userName == tr.username) {
                found = true;
                
                Color::setCyanTextColor();
                std::cout << "------------------- Bus Ticket ---------------------\n\n";
                Color::resetTextColor();

                std::cout << "Username: " << tr.username << "\n";
                std::cout << "Bus ID: " << tr.busID << "\n";
                std::cout << "Seat Number: " << tr.seatNumber << "\n";
                std::cout << "Seat Fare: " << tr.fare << "\n";
                std::cout << "Route: " << tr.departureCity << " to " << tr.arrivalCity << "\n";
                std::cout << "Departure Date: " << tr.departureDate << "\n";
                std::cout << "Departure Time: " << tr.departureTime << "\n";
                std::cout << "Arrival Date: " << tr.arrivalDate << "\n";
                std::cout << "Arrival Time: " << tr.arrivalTime << "\n";
                std::cout << "Booking Time: " << tr.bookingTime << "\n";

                Color::setCyanTextColor();
                std::cout << "----------------------------------------------------\n";
                Color::resetTextColor();
            }
        }
        bookingIn.close();

        if (!found) {
            Print::Error("No Ticket Record Found for the User");
            return false;
        }

        return true;
    }

    static bool cancelUserTicket(const std::string& temp) {
        if (!Validation::isValidUsername(temp)) return false;

        std::string userName = Validation::getUsernameFromFile(temp);

        if (userName == "") {
            Print::Error("Username doesn't exist.");
            return false;
        }

        std::string busID = "";
        std::ifstream checkTicketDetails("Bus_Booking.txt");
        if (Validation::isFileEmpty(checkTicketDetails, "Bus_Booking")) {
            return false;
        }
        checkTicketDetails.close();
        while (true) {
            system("cls");
            Color::setCyanTextColor();
            std::cout << "----------------------------------------------------\n";
            std::cout << "         Bus Ticket Cancellation Interface          \n";
            std::cout << "----------------------------------------------------\n\n";
            Color::resetTextColor();
            std::cout << "Enter Bus ID for the Seat Booked: ";
            getline(std::cin, busID);
            if (!Validation::isValidID(busID, "Bus ID") || !Validation::isValidInteger(busID, "Bus ID")) {
                system("pause");
            }
            else {
                break;
            }
            Color::setLightYellowTextColor();
            std::cout << "\nRe-enter Seat Number?" << std::endl;
            Color::resetTextColor();
            std::cout << "Enter Yes or No (Default Yes): ";
            getline(std::cin, busID);
            if (busID == "No" || busID == "no") {
                return false;
            }
        }
        if (!Validation::doesDataExistInBusFile(busID, '1')) {
            Print::Error("Bus ID doesn't exist.");
            return false;
        }
        std::ifstream readBusData("Bus_Data.txt");
        if (readBusData.fail()) {
            Print::Error("Bus_Data File not Found.");
            return false;
        }
        BusRecord record;
        std::string line = "";
        while (getline(readBusData, line)) {
            std::istringstream in(line);
            getline(in, record.busID, '|');
            getline(in, record.numberPlate, '|');
            getline(in, record.type, '|');
            getline(in, record.totalSeat, '|');
            getline(in, record.fare, '|');

            getline(in, record.driverID, '|');
            getline(in, record.driverName, '|');
            getline(in, record.driverAge, '|');
            getline(in, record.driverPhoneNumber, '|');

            getline(in, record.departureCity, '|');
            getline(in, record.departureDate, '|');
            getline(in, record.departureTime, '|');

            getline(in, record.arrivalCity, '|');
            getline(in, record.arrivalDate, '|');
            getline(in, record.arrivalTime);
            if (record.busID == busID) {
                std::ifstream readSeatsData("Bus_" + busID + "_Seats.txt");
                if (!readSeatsData.fail()) {            //Assuming File Exists
                    bool availableSeat;
                    while (readSeatsData >> availableSeat) {
                        if (availableSeat)
                            record.numberOfAvailableSeats++;
                    }
                }
                readSeatsData.close();
                break;
            }
        }
        readBusData.close();
        int totSeat = std::stoi(record.totalSeat);
        bool* availSeats = new bool[totSeat]();
        int status = -1;
        //Load Seat Availability and Unavailability in availSeats
        std::ifstream readAvailableSeats("Bus_" + record.busID + "_Seats.txt");
        for (int i = 0; i < totSeat; i++) {
            if (readAvailableSeats >> status) {
                if (status == 1) {
                    availSeats[i] = true;
                }
                else {
                    availSeats[i] = false;
                }
            }
        }
        readAvailableSeats.close();
        std::string seatNum = "";   //Seat Number (string)
        int seatNumber = 0;         //Seat Number (int) converted from string
        while (true) {
            system("cls");
            Color::setCyanTextColor();
            std::cout << "----------------------------------------------------\n";
            std::cout << "         Bus Ticket Cancellation Interface          \n";
            std::cout << "----------------------------------------------------\n\n";
            Color::resetTextColor();

            std::cout << "Enter Seat Number: ";
            getline(std::cin, seatNum);
            if (Validation::isValidSeatNumber(seatNum, "Bus Seat Number") && Validation::isValidInteger(seatNum, "Bus Seat Number")) {  //Validate if input is Valid Seat Number
                seatNumber = std::stoi(seatNum);
                if (seatNumber < 1 || seatNumber > totSeat) {       //Validate if Seat Number with in Range
                    Print::Error("Invalid Seat Number.");
                }
                else if (availSeats[seatNumber - 1]) {              //Add User Match Here!
                    Print::Error("Seat isn't Booked.");
                }
                else {
                    break;
                }
                Color::setLightYellowTextColor();
                std::cout << "\nRe-enter Seat Number?" << std::endl;
                Color::resetTextColor();
                std::cout << "Enter Yes or No (Default Yes): ";
                getline(std::cin, seatNum);
                if (seatNum == "No" || seatNum == "no") {
                    return false;
                }
            }
        }


        //Ask for confirmation
        std::string choice;
        Color::setLightYellowTextColor();
        std::cout << "Confirm Ticket Deletion?" << std::endl;
        Color::resetTextColor();
        std::cout << "Enter Yes or No (No as Default): ";
        getline(std::cin, choice);
        if (choice != "yes" && choice != "Yes") {
            Print::Error("Ticket Deletion Cancelled.");
            delete[] availSeats;
            return false;
        }

        // Mark the selected seat as Available
        availSeats[seatNumber - 1] = true;
        std::ofstream writeSeatData("Bus_" + record.busID + "_Seats.txt", std::ios::trunc);
        if (writeSeatData.fail()) {
            Print::Error("Unable to open Bus_" + busID + "_Seats File.");
            delete[] availSeats;
            return false;
        }
        for (int i = 0; i < totSeat; i++) {
            writeSeatData << (availSeats[i] ? "1" : "0") << "\n";
        }
        writeSeatData.close();

        /*
            Ticket Saving Format
            0. Username         1. Bus ID           2. Seat Number      3. Fare
            4. Departure City   5. Departure Date   6. Departure Time
            7. Arrival City     8. Arrival Date     9. Arrival Time
            10. Booking Time
        */

        BusTicketRecord tr;
        bool found = false;
        std::ifstream readTicketDetails("Bus_Booking.txt");
        std::string keptData = "";
        line = "";
        while (getline(readTicketDetails, line)) {
            std::istringstream in(line);
            getline(in, tr.username, '|');
            getline(in, tr.busID, '|');
            getline(in, tr.seatNumber, '|');
            getline(in, tr.fare, '|');
            getline(in, tr.departureCity, '|');
            getline(in, tr.departureDate, '|');
            getline(in, tr.departureTime, '|');
            getline(in, tr.arrivalCity, '|');
            getline(in, tr.arrivalDate, '|');
            getline(in, tr.arrivalTime, '|');
            getline(in, tr.bookingTime);

            if (tr.busID == record.busID && tr.seatNumber == seatNum && userName == tr.username) {     //SeatNum is string and stores the the value that was entered during first input
                found = true;
                continue;
            }

            keptData += tr.username + "|" + tr.busID + "|" + tr.seatNumber + "|" + tr.fare + "|"
                + tr.departureCity + "|" + tr.departureDate + "|" + tr.departureTime + "|"
                + tr.arrivalCity + "|" + tr.arrivalDate + "|" + tr.arrivalTime + "|"
                + tr.bookingTime + "\n";
        }
        if (!found) {
            Print::Error("Seat Number Not Found.");
            delete[] availSeats;
            return false;
        }
        std::ofstream writeTicketDetails("Bus_Booking.txt", std::ios::trunc);
        if (writeTicketDetails.fail()) {
            Print::Error("Unable to open Bus_Booking File.");
            delete[] availSeats;
            return false;
        }
        writeTicketDetails << keptData;
        writeTicketDetails.close();
        Print::Success("Ticket Deleted Successfuly.");
        delete[] availSeats;
        availSeats = nullptr;
        return false;
    }
};

class UserBusFunctionality {
public:
    static void searchBuses() {
        std::ifstream fin("Bus_Data.txt");
        if (!fin) {
            Print::Error("Bus_Data.txt file not found.");
            system("pause");
            return;
        }

        std::string arrivalCity, departureCity, departureDate;

        while (true) {
            system("cls");
            Color::setCyanTextColor();
            std::cout << "----------------------------------------------------\n";
            std::cout << "                Bus Search Interface                \n";
            std::cout << "----------------------------------------------------\n\n";
            Color::resetTextColor();
            std::cout << "Enter Departure City: ";
            getline(std::cin, departureCity);
            if (Validation::isValidCity(departureCity, "Departure City")) {
                break;
            }
            Color::setLightYellowTextColor();
            std::cout << "\nRe-enter Departure City?" << std::endl;
            Color::resetTextColor();
            std::cout << "Enter Yes or No (Default Yes): ";
            getline(std::cin, departureCity);
            if (departureCity == "No" || departureCity == "no") {
                return;
            }
        }
        while (true) {
            system("cls");
            Color::setCyanTextColor();
            std::cout << "----------------------------------------------------\n";
            std::cout << "                Bus Search Interface                \n";
            std::cout << "----------------------------------------------------\n\n";
            Color::resetTextColor();
            std::cout << "Enter Arrival City: ";
            getline(std::cin, arrivalCity);
            if (Validation::isValidCity(arrivalCity, "Arrival City")) {
                break;
            }
            Color::setLightYellowTextColor();
            std::cout << "\nRe-enter Arrival City?" << std::endl;
            Color::resetTextColor();
            std::cout << "Enter Yes or No (Default Yes): ";
            getline(std::cin, arrivalCity);
            if (arrivalCity == "No" || arrivalCity == "no") {
                return;
            }
        }
        while (true) {
            system("cls");
            Color::setCyanTextColor();
            std::cout << "----------------------------------------------------\n";
            std::cout << "                Bus Search Interface                \n";
            std::cout << "----------------------------------------------------\n\n";
            Color::resetTextColor();
            std::cout << "Enter Departure Date: ";
            getline(std::cin, departureDate);
            if (Validation::isValidDateFormat(departureDate, "Departure Date")) {
                break;
            }
            Color::setLightYellowTextColor();
            std::cout << "\nRe-enter Departure Date?" << std::endl;
            Color::resetTextColor();
            std::cout << "Enter Yes or No (Default Yes): ";
            getline(std::cin, departureDate);
            if (departureDate == "No" || departureDate == "no") {
                return;
            }
        }

        bool found = false;
        BusRecord record;
        std::string line = "";
        system("cls");
        Color::setCyanTextColor();
        std::cout << "----------------------------------------------------\n";
        std::cout << "                Bus Search Interface                \n";
        std::cout << "----------------------------------------------------\n\n";
        Color::resetTextColor();

        while (getline(fin, line)) {
            std::istringstream in(line);
            getline(in, record.busID, '|');
            getline(in, record.numberPlate, '|');
            getline(in, record.type, '|');
            getline(in, record.totalSeat, '|');
            getline(in, record.fare, '|');

            getline(in, record.driverID, '|');
            getline(in, record.driverName, '|');
            getline(in, record.driverAge, '|');
            getline(in, record.driverPhoneNumber, '|');

            getline(in, record.departureCity, '|');
            getline(in, record.departureDate, '|');
            getline(in, record.departureTime, '|');

            getline(in, record.arrivalCity, '|');
            getline(in, record.arrivalDate, '|');
            getline(in, record.arrivalTime);
            if (record.departureCity == departureCity && record.arrivalCity == arrivalCity && record.departureDate == departureDate) {
                std::ifstream readAvailableSeats("Bus_" + record.busID + "_Seats.txt");
                if (!readAvailableSeats.fail()) {       //If Seats File exists then run
                    bool availableSeat;
                    while (readAvailableSeats >> availableSeat) {
                        if (availableSeat)
                            record.numberOfAvailableSeats++;
                    }
                }
                TransportDetailsDisplay::displayBusDetailsForUser(record);
                found = true;
            }
        }

        fin.close();
        if (!found) {
            Print::Error("No bus records found for the given criteria.");
        }
    }

    static void viewBuses() {
        std::ifstream fin("Bus_Data.txt");
        if (!fin) {
            Print::Error("Bus_Data.txt file not found.");
            system("pause");
            return;
        }
        bool found = false;
        BusRecord record;
        std::string line = "";

        while (getline(fin, line)) {
            std::istringstream in(line);
            getline(in, record.busID, '|');
            getline(in, record.numberPlate, '|');
            getline(in, record.type, '|');
            getline(in, record.totalSeat, '|');
            getline(in, record.fare, '|');

            getline(in, record.driverID, '|');
            getline(in, record.driverName, '|');
            getline(in, record.driverAge, '|');
            getline(in, record.driverPhoneNumber, '|');

            getline(in, record.departureCity, '|');
            getline(in, record.departureDate, '|');
            getline(in, record.departureTime, '|');

            getline(in, record.arrivalCity, '|');
            getline(in, record.arrivalDate, '|');
            getline(in, record.arrivalTime);
            std::ifstream readAvailableSeats("Bus_" + record.busID + "_Seats.txt");
            record.numberOfAvailableSeats = 0;
            if (!readAvailableSeats.fail()) {       //If Seats File exists then run
                bool availableSeat;
                while (readAvailableSeats >> availableSeat) {
                    if (availableSeat)
                        record.numberOfAvailableSeats++;
                }
            }
            TransportDetailsDisplay::displayBusDetailsForUser(record);
            found = true;
        }
        fin.close();
        if (!found) {
            Print::Error("No bus records found.");
        }
        return;
    }

    static void bookSeat(const std::string& userName) {
        std::string busID;
        while (true) {
            system("cls");
            Color::setCyanTextColor();
            std::cout << "----------------------------------------------------\n";
            std::cout << "             Bus Seat Booking Interface             \n";
            std::cout << "----------------------------------------------------\n\n";
            Color::resetTextColor();
            std::cout << "Enter Bus ID for Booking: ";
            getline(std::cin, busID);
            if (!Validation::isValidID(busID, "Bus ID")) {
                system("pause");
            }
            else {
                break;
            }
            Color::setLightYellowTextColor();
            std::cout << "\nRe-enter Bus ID?" << std::endl;
            Color::resetTextColor();
            std::cout << "Enter Yes or No (Default Yes): ";
            getline(std::cin, busID);
            if (busID == "No" || busID == "no") {
                return;
            }
        }
        if (!Validation::doesDataExistInBusFile(busID, '1')) {
            Print::Error("Bus ID doesn't exist.");
            return;
        }
        //Open Bus_Data File to load data about bus from it
        //Open Bus_(BusID)_Seats File to load available and unavailable seats on the selected bus
        std::ifstream readBusData("Bus_Data.txt");
        std::ifstream readSeatData("Bus_" + busID + "_Seats.txt");
        if (readBusData.fail()) {
            Print::Error("Bus_Data File not Found.");
            return;
        }
        if (readSeatData.fail()) {
            Print::Error("Bus_" + busID + "_Seats File not Found.");
            return;
        }
        //Load Data from file in br (Bus Record)
        BusRecord record;;
        std::string line = "";

        system("cls");
        Color::setCyanTextColor();
        std::cout << "----------------------------------------------------\n";
        std::cout << "             Bus Seat Booking Interface             \n";
        std::cout << "----------------------------------------------------\n\n";
        Color::resetTextColor();

        while (getline(readBusData, line)) {

            std::istringstream in(line);
            getline(in, record.busID, '|');
            getline(in, record.numberPlate, '|');
            getline(in, record.type, '|');
            getline(in, record.totalSeat, '|');
            getline(in, record.fare, '|');

            getline(in, record.driverID, '|');
            getline(in, record.driverName, '|');
            getline(in, record.driverAge, '|');
            getline(in, record.driverPhoneNumber, '|');

            getline(in, record.departureCity, '|');
            getline(in, record.departureDate, '|');
            getline(in, record.departureTime, '|');

            getline(in, record.arrivalCity, '|');
            getline(in, record.arrivalDate, '|');
            getline(in, record.arrivalTime);
            if (record.busID == busID) {
                std::ifstream readAvailableSeats("Bus_" + record.busID + "_Seats.txt");
                if (!readAvailableSeats.fail()) {       //If Seats File exists then run
                    bool availableSeat;
                    while (readAvailableSeats >> availableSeat) {
                        if (availableSeat)
                            record.numberOfAvailableSeats++;
                    }
                }
                break;
            }
        }
        //Display Bus Details
        TransportDetailsDisplay::displayBusDetailsForUser(record);
        system("pause");
        system("cls");
        Color::setCyanTextColor();
        std::cout << "----------------------------------------------------\n";
        std::cout << "             Bus Seat Booking Interface             \n";
        std::cout << "----------------------------------------------------\n\n";
        Color::resetTextColor();
        //Show All the Seat Numbers
        std::cout << "Available Seat Numbers: \n";
        int totSeats = std::stoi(record.totalSeat);
        bool* availSeats = new bool[totSeats];
        int availCount = 0;
        int status = 0;
        //Print 
        for (int i = 0; i < totSeats; i++) {
            if (readSeatData >> status) {
                if (status == 1) {
                    availSeats[i] = true;
                    Color::setGreenTextColor();
                    std::cout << std::setw(3) << (i + 1);
                    Color::resetTextColor();
                    availCount++;
                }
                else {
                    Color::setRedTextColor();
                    std::cout << std::setw(3) << (i + 1);
                    Color::resetTextColor();
                    availSeats[i] = false;
                }
                if ((i + 1) % 4 == 0) std::cout << std::endl;
            }
        }
        readSeatData.close();
        //If all the seats are booked prompt the user and exit
        if (availCount == 0) {
            Print::Error("No available seats for this bus.");
            delete[] availSeats;
            return;
        }

        std::string seatInput = "";
        int seatNumber = 0;
        //Input Seat Number to Book
        while (true) {
            std::cout << "\nEnter seat number to book: ";
            getline(std::cin, seatInput);
            if (Validation::isValidSeatNumber(seatInput, "Seat Number") &&
                Validation::isValidInteger(seatInput, "Seat Number")) {
                seatNumber = std::stoi(seatInput);
                if (seatNumber < 1 || seatNumber > totSeats)
                    Print::Error("Invalid Seat Number.");
                else if (!availSeats[seatNumber - 1])
                    Print::Error("Seat already booked.");
                else
                    break;
                Color::setLightYellowTextColor();
                std::cout << "\nRe-enter Seat Number?" << std::endl;
                Color::resetTextColor();
                std::cout << "Enter Yes or No (Default Yes): ";
                getline(std::cin, seatInput);
                if (seatInput == "No" || seatInput == "no") {
                    return;
                }
            }
        }

        //Ask for confirmation
        std::string choice;
        Color::setLightYellowTextColor();
        std::cout << "\nConfirm Seat?" << std::endl;
        Color::resetTextColor();
        std::cout << "Enter Yes or No (No as Default): ";
        getline(std::cin, choice);
        if (choice != "yes" && choice != "Yes") {
            Print::Error("Booking Cancelled.");
            delete[] availSeats;
            return;
        }

        //Simulate Payment
        system("cls");
        PaymentDetails userPayment;
        userPayment = PaymentInterface::makePayment();

        system("cls");

        Color::setCyanTextColor();
        std::cout << "----------------------------------------------------\n";
        std::cout << "             Bus Seat Booking Interface             \n";
        std::cout << "----------------------------------------------------\n\n";
        Color::resetTextColor();
        // Mark the selected seat as booked
        availSeats[seatNumber - 1] = false;
        std::ofstream writeSeatData("Bus_" + busID + "_Seats.txt", std::ios::trunc);
        if (writeSeatData.fail()) {
            Print::Error("Unable to open Bus_" + busID + "_Seats File.");
            delete[] availSeats;
            return;
        }
        for (int i = 0; i < totSeats; i++) {
            writeSeatData << (availSeats[i] ? "1" : "0") << "\n";
        }
        writeSeatData.close();
        Print::Success("Ticket Booked.");

        std::ofstream writeTicketDetails("Bus_Booking.txt", std::ios::app);
        /*
            Saving Format
            0. Username         1. Bus ID           2. Seat Number      3. Fare
            4. Departure City   5. Departure Date   6. Departure Time
            7. Arrival City     8. Arrival Date     9. Arrival Time
            10. Booking Time
        */
        std::time_t localTime = std::time(0);
        char buffer[26];
        if (ctime_s(buffer, sizeof(buffer), &localTime) != 0) {
            Print::Error("Unable to get Current Time for Ticket Log");
            delete[] availSeats;
            return;
        }
        std::string currentTime(buffer);

        if (writeTicketDetails.fail()) {
            Print::Error("Unable to open Booking File.");
            delete[] availSeats;
            return;
        }
        writeTicketDetails << userName << "|" << record.busID << "|" << seatNumber << "|" << record.fare << "|"
            << record.departureCity << "|" << record.departureDate << "|" << record.departureTime << "|"
            << record.arrivalCity << "|" << record.arrivalDate << "|" << record.arrivalTime << "|"
            << currentTime;
        writeTicketDetails.close();
        delete[] availSeats;
        availSeats = nullptr;
        return;
    }

    static void cancelTicket(const std::string& userName) {
        std::string busID = "";
        std::ifstream checkTicketDetails("Bus_Booking.txt");
        if (Validation::isFileEmpty(checkTicketDetails, "Bus_Booking")) {
            return;
        }
        checkTicketDetails.close();
        while (true) {
            system("cls");
            Color::setCyanTextColor();
            std::cout << "----------------------------------------------------\n";
            std::cout << "       Bus Seat Ticket Cancellation Interface       \n";
            std::cout << "----------------------------------------------------\n\n";
            Color::resetTextColor();
            std::cout << "Enter Bus ID for the Seat Booked: ";
            getline(std::cin, busID);
            if (!Validation::isValidID(busID, "Bus ID") && Validation::isValidInteger(busID, "Bus ID")) {
                system("pause");
            }
            else {
                break;
            }
            Color::setLightYellowTextColor();
            std::cout << "\nRe-enter Bus ID?" << std::endl;
            Color::resetTextColor();
            std::cout << "Enter Yes or No (Default Yes): ";
            getline(std::cin, busID);
            if (busID == "No" || busID == "no") {
                return;
            }
        }
        if (!Validation::doesDataExistInBusFile(busID, '1')) {
            Print::Error("Bus ID doesn't exist.");
            return;
        }
        std::ifstream readBusData("Bus_Data.txt");
        if (readBusData.fail()) {
            Print::Error("Bus_Data File not Found.");
            return;
        }
        BusRecord record;
        std::string line = "";

        while (getline(readBusData, line)) {
            std::istringstream in(line);
            getline(in, record.busID, '|');
            getline(in, record.numberPlate, '|');
            getline(in, record.type, '|');
            getline(in, record.totalSeat, '|');
            getline(in, record.fare, '|');

            getline(in, record.driverID, '|');
            getline(in, record.driverName, '|');
            getline(in, record.driverAge, '|');
            getline(in, record.driverPhoneNumber, '|');

            getline(in, record.departureCity, '|');
            getline(in, record.departureDate, '|');
            getline(in, record.departureTime, '|');

            getline(in, record.arrivalCity, '|');
            getline(in, record.arrivalDate, '|');
            getline(in, record.arrivalTime);
            if (record.busID == busID) {
                std::ifstream readSeatsData("Bus_" + busID + "_Seats.txt");
                if (!readSeatsData.fail()) {            //Assuming File Exists
                    bool availableSeat;
                    while (readSeatsData >> availableSeat) {
                        if (availableSeat)
                            record.numberOfAvailableSeats++;
                    }
                }
                readSeatsData.close();
                break;
            }
        }
        readBusData.close();
        int totSeat = std::stoi(record.totalSeat);
        bool* availSeats = new bool[totSeat]();
        int status = -1;
        //Load Seat Availability and Unavailability in availSeats
        std::ifstream readAvailableSeats("Bus_" + record.busID + "_Seats.txt");
        for (int i = 0; i < totSeat; i++) {
            if (readAvailableSeats >> status) {
                if (status == 1) {
                    availSeats[i] = true;
                }
                else {
                    availSeats[i] = false;
                }
            }
        }
        readAvailableSeats.close();
        std::string seatNum = "";   //Seat Number (string)
        int seatNumber = 0;         //Seat Number (int) converted from string
        while (true) {
            system("cls");
            Color::setCyanTextColor();
            std::cout << "----------------------------------------------------\n";
            std::cout << "       Bus Seat Ticket Cancellation Interface       \n";
            std::cout << "----------------------------------------------------\n\n";
            Color::resetTextColor();
            std::cout << "Enter Seat Number: ";
            getline(std::cin, seatNum);
            if (!Validation::isValidSeatNumber(seatNum, "Bus Seat Number") || !Validation::isValidInteger(seatNum, "Bus Seat Number")) {  //Validate if input is Valid Seat Number
                system("pause");
            }
            else {
                seatNumber = std::stoi(seatNum);
                if (seatNumber < 1 || seatNumber > totSeat) {       //Validate if Seat Number with in Range
                    Print::Error("Invalid Seat Number.");
                    system("pause");
                }
                else if (availSeats[seatNumber - 1]) {              //Add User Match Here!
                    Print::Error("Seat isn't Booked.");
                    system("pause");
                }
                else {
                    break;
                }
                Color::setLightYellowTextColor();
                std::cout << "\nRe-enter Seat Number?" << std::endl;
                Color::resetTextColor();
                std::cout << "Enter Yes or No (Default Yes): ";
                getline(std::cin, seatNum);
                if (seatNum == "No" || seatNum == "no") {
                    return;
                }
            }
        }

        //Ask for confirmation
        std::string choice;
        Color::setLightYellowTextColor();
        std::cout << "\nConfirm Ticket Deletion?" << std::endl;
        Color::resetTextColor();
        std::cout << "Enter Yes or No (No as Default): ";
        getline(std::cin, choice);
        if (choice != "yes" && choice != "Yes") {
            Print::Error("Ticket Deletion Cancelled.");
            delete[] availSeats;
            return;
        }

        // Mark the selected seat as Available
        availSeats[seatNumber - 1] = true;
        std::ofstream writeSeatData("Bus_" + record.busID + "_Seats.txt", std::ios::trunc);
        if (writeSeatData.fail()) {
            Print::Error("Unable to open Bus_" + busID + "_Seats File.");
            delete[] availSeats;
            return;
        }
        for (int i = 0; i < totSeat; i++) {
            writeSeatData << (availSeats[i] ? "1" : "0") << "\n";
        }
        writeSeatData.close();

        /*
            Ticket Saving Format
            0. Username         1. Bus ID           2. Seat Number      3. Fare
            4. Departure City   5. Departure Date   6. Departure Time
            7. Arrival City     8. Arrival Date     9. Arrival Time
            10. Booking Time
        */

        BusTicketRecord tr;
        bool found = false;
        std::ifstream readTicketDetails("Bus_Booking.txt");
        std::string keptData = "";
        line = "";
        while (getline(readTicketDetails, line)) {
            std::istringstream in(line);
            getline(in, tr.username, '|');
            getline(in, tr.busID, '|');
            getline(in, tr.seatNumber, '|');
            getline(in, tr.fare, '|');
            getline(in, tr.departureCity, '|');
            getline(in, tr.departureDate, '|');
            getline(in, tr.departureTime, '|');
            getline(in, tr.arrivalCity, '|');
            getline(in, tr.arrivalDate, '|');
            getline(in, tr.arrivalTime, '|');
            getline(in, tr.bookingTime);

            if (tr.busID == record.busID && tr.seatNumber == seatNum && userName == tr.username) {     //SeatNum is string and stores the the value that was entered during first input
                found = true;
                continue;
            }

            keptData += tr.username + "|" + tr.busID + "|" + tr.seatNumber + "|" + tr.fare + "|"
                + tr.departureCity + "|" + tr.departureDate + "|" + tr.departureTime + "|"
                + tr.arrivalCity + "|" + tr.arrivalDate + "|" + tr.arrivalTime + "|"
                + tr.bookingTime + "\n";
        }
        if (!found) {
            Print::Error("Seat Number Not Found.");
            delete[] availSeats;
            return;
        }
        std::ofstream writeTicketDetails("Bus_Booking.txt", std::ios::trunc);
        if (writeTicketDetails.fail()) {
            Print::Error("Unable to open Bus_Booking File.");
            delete[] availSeats;
            return;
        }
        writeTicketDetails << keptData;
        writeTicketDetails.close();
        Print::Success("Ticket Deleted Successfuly.");
        delete[] availSeats;
        availSeats = nullptr;
        return;
    }

    static void viewBookingHistory(const std::string& userName) {
        std::ifstream bookingIn("Bus_Booking.txt");
        if (!bookingIn) {
            Print::Error("No booking records found.");
            return;
        }

        Color::setCyanTextColor();
        std::cout << "----------------------------------------------------\n";
        std::cout << "                  Booking History                   \n";
        std::cout << "----------------------------------------------------\n\n";
        Color::resetTextColor();

        std::string line;
        BusTicketRecord tr;
        bool found = false;
        /*
            Ticket Saving Format
            1. Bus ID           2. Seat Number      3. Fare
            4. Departure City   5. Departure Date   6. Departure Time
            7. Arrival City     8. Arrival Date     9. Arrival Time
            10. Booking Time
        */
        while (getline(bookingIn, line)) {
            std::istringstream in(line);
            getline(in, tr.username, '|');
            getline(in, tr.busID, '|');
            getline(in, tr.seatNumber, '|');
            getline(in, tr.fare, '|');

            getline(in, tr.departureCity, '|');
            getline(in, tr.departureDate, '|');
            getline(in, tr.departureTime, '|');

            getline(in, tr.arrivalCity, '|');
            getline(in, tr.arrivalDate, '|');
            getline(in, tr.arrivalTime, '|');

            getline(in, tr.bookingTime);

            if (userName == tr.username) {
                found = true;

                Color::setCyanTextColor();
                std::cout << "------------------- Bus Ticket ---------------------\n\n";
                Color::resetTextColor();

                std::cout << "Username: " << tr.username << "\n";
                std::cout << "Bus ID: " << tr.busID << "\n";
                std::cout << "Seat Number: " << tr.seatNumber << "\n";
                std::cout << "Seat Fare: " << tr.fare << "\n";
                std::cout << "Route: " << tr.departureCity << " to " << tr.arrivalCity << "\n";
                std::cout << "Departure Date: " << tr.departureDate << "\n";
                std::cout << "Departure Time: " << tr.departureTime << "\n";
                std::cout << "Arrival Date: " << tr.arrivalDate << "\n";
                std::cout << "Arrival Time: " << tr.arrivalTime << "\n";
                std::cout << "Booking Time: " << tr.bookingTime << "\n";

                Color::setCyanTextColor();
                std::cout << "----------------------------------------------------\n";
                Color::resetTextColor();
            }
        }
        bookingIn.close();

        if (!found) {
            Print::Error("No Booking History Found.");
        }

        return;
    }
};

class BusInterface {
public:
    static void adminBusMain() {
        while (true) {
            system("cls");
            std::string choice = "\0";
            Color::setCyanTextColor();
            std::cout << "----------------------------------------------------\n";
            std::cout << "                     Admin Menu                     \n";
            std::cout << "----------------------------------------------------\n\n";
            Color::resetTextColor();
            std::cout << "1. Add Bus" << std::endl;
            std::cout << "2. Edit Bus" << std::endl;
            std::cout << "3. Delete Bus" << std::endl;
            std::cout << "4. View All Buses" << std::endl;
            std::cout << "5. Search Bus" << std::endl;
            std::cout << "6. View All Tickets" << std::endl;
            std::cout << "7. View Ticket of a User" << std::endl;
            std::cout << "8. Cancel Ticket of a User" << std::endl;
            std::cout << "9. Exit" << std::endl << std::endl;
            std::cout << "Enter your choice (Default Exit Option): ";
            getline(std::cin, choice);

            if (choice == "1") {            //Add a bus
                system("cls");
                adminBusFunctionality::addBus();
                system("pause");
            }

            else if (choice == "2") {       //Edit a Specific Bus
                while (true) {
                    system("cls");
                    Color::setCyanTextColor();
                    std::cout << "----------------------------------------------------\n";
                    std::cout << "                 Edit Bus Interface                 \n";
                    std::cout << "----------------------------------------------------\n\n";
                    Color::resetTextColor();
                    std::string input;
                    std::cout << "Enter Bus ID to Edit:";
                    getline(std::cin, input);
                    if (adminBusFunctionality::editBus(input)) {
                        system("pause");
                        break;
                    }
                    Color::setLightYellowTextColor();
                    std::cout << "\nRe-enter Bus ID?" << std::endl;
                    Color::resetTextColor();
                    std::cout << "Enter Yes or No (Default Yes): ";
                    getline(std::cin, input);
                    if (input == "No" || input == "no") {
                        break;
                    }
                }
            }

            else if (choice == "3") {       //Delete a Specific Bus
                while (true) {
                    system("cls");
                    std::string input;
                    Color::setCyanTextColor();
                    std::cout << "----------------------------------------------------\n";
                    std::cout << "                Delete Bus Interface                \n";
                    std::cout << "----------------------------------------------------\n\n";
                    Color::resetTextColor();
                    std::cout << "Enter Bus ID to Delete:";
                    getline(std::cin, input);
                    if (adminBusFunctionality::deleteBus(input)) {
                        system("pause");
                        break;
                    }
                    Color::setLightYellowTextColor();
                    std::cout << "\nRe-enter Bus ID?" << std::endl;
                    Color::resetTextColor();
                    std::cout << "Enter Yes or No (Default Yes): ";
                    getline(std::cin, input);
                    if (input == "No" || input == "no") {
                        break;
                    }
                }
            }

            else if (choice == "4") {       //View all the Buses
                system("cls");
                Color::setCyanTextColor();
                std::cout << "----------------------------------------------------\n";
                std::cout << "                Bus Details Interface               \n";
                std::cout << "----------------------------------------------------\n\n";
                Color::resetTextColor();
                adminBusFunctionality::viewBuses();
                system("pause");
            }

            else if (choice == "5") {       //Search a Specific Bus
                while (true) {
                    system("cls");
                    std::string input;
                    Color::setCyanTextColor();
                    std::cout << "----------------------------------------------------\n";
                    std::cout << "                Search Bus Interface                \n";
                    std::cout << "----------------------------------------------------\n\n";
                    Color::resetTextColor();
                    std::cout << "Enter Bus ID to Search: ";
                    getline(std::cin, input);
                    if (adminBusFunctionality::searchBus(input)) {
                        break;
                    }
                    Color::setLightYellowTextColor();
                    std::cout << "\nRe-enter Bus ID?" << std::endl;
                    Color::resetTextColor();
                    std::cout << "Enter Yes or No (Default Yes): ";
                    getline(std::cin, input);
                    if (input == "No" || input == "no") {
                        break;
                    }
                }
            }

            else if (choice == "6") {       //View all the Booked Seats Ticket
                system("cls");
                adminBusFunctionality::viewAllBookingHistory();
                system("pause");
            }

            else if (choice == "7") {       //View the Booked Seats Ticket of a Specific User
                while (true) {
                    system("cls");
                    std::string input;
                    Color::setCyanTextColor();
                    std::cout << "----------------------------------------------------\n";
                    std::cout << "                 Bus Ticket History                 \n";
                    std::cout << "----------------------------------------------------\n\n";
                    Color::resetTextColor();
                    std::cout << "Enter Username to search: ";
                    getline(std::cin, input);
                    if (adminBusFunctionality::viewBookingHistoryOfAUser(input)) {
                        system("pause");
                        break;
                    }
                    Color::setLightYellowTextColor();
                    std::cout << "\nRe-enter Username?" << std::endl;
                    Color::resetTextColor();
                    std::cout << "Enter Yes or No (Default Yes): ";
                    getline(std::cin, input);
                    if (input == "No" || input == "no") {
                        break;
                    }
                }
            }

            else if (choice == "8") {       //Cancel the Booked Seats Ticket of a Specific User
                while (true) {
                    system("cls");
                    std::string input;
                    Color::setCyanTextColor();
                    std::cout << "----------------------------------------------------\n";
                    std::cout << "         Bus Ticket Cancellation Interface          \n";
                    std::cout << "----------------------------------------------------\n\n";
                    Color::resetTextColor();
                    std::cout << "Enter Username to search: ";
                    getline(std::cin, input);
                    if (adminBusFunctionality::cancelUserTicket(input)) {
                        system("pause");
                        break;
                    }
                    else {
                        Color::setLightYellowTextColor();
                        std::cout << "\nRe-enter Username?" << std::endl;
                        Color::resetTextColor();
                        std::cout << "Enter Yes or No (Default Yes): ";
                        getline(std::cin, input);
                        if (input == "No" || input == "no") {
                            break;
                        }
                    }
                }
            }

            else if (choice == "9") {
                Color::setLightMagentaTextColor();
                std::cout << "\nExiting Admin Menu....\n\n";
                Color::resetTextColor();
                system("pause");
                return;
            }

            else {
                Print::Error("Invalid Choice!");
                system("pause");
            }
        }
    }

    static void userBusMain(const std::string& userName) {
        while (true) {
            system("cls");
            std::string choice;
            Color::setCyanTextColor();
            std::cout << "----------------------------------------------------\n";
            std::cout << "                     User Menu                      \n";
            std::cout << "----------------------------------------------------\n\n";
            Color::resetTextColor();
            std::cout << "1. Search Buses\n";
            std::cout << "2. View All Buses\n";
            std::cout << "3. Book Seat\n";
            std::cout << "4. Cancel Ticket\n";
            std::cout << "5. View Booking History\n";
            std::cout << "6. Exit\n";
            std::cout << "Enter your choice: ";
            getline(std::cin, choice);

            if (choice == "1") {
                system("cls");
                UserBusFunctionality::searchBuses();
                system("pause");
            }
            else if (choice == "2") {
                system("cls");
                Color::setCyanTextColor();
                std::cout << "----------------------------------------------------\n";
                std::cout << "                Bus Details Interface               \n";
                std::cout << "----------------------------------------------------\n\n";
                Color::resetTextColor();

                UserBusFunctionality::viewBuses();
                system("pause");
            }
            else if (choice == "3") {
                system("cls");
                UserBusFunctionality::bookSeat(userName);
                system("pause");
            }
            else if (choice == "4") {
                system("cls");
                UserBusFunctionality::cancelTicket(userName);
                system("pause");
            }
            else if (choice == "5") {
                system("cls");
                UserBusFunctionality::viewBookingHistory(userName);
                system("pause");
            }
            else if (choice == "6") {
                Color::setLightMagentaTextColor();
                std::cout << "\nExiting User Menu...\n\n";
                Color::resetTextColor();
                system("pause");
                break;
            }
            else {
                Print::Error("Invalid Choice!");
                system("pause");
            }
        }
    }
};

class MovieDetails {
private:
    //movie
    int movieID;
    std::string title, genre, duration, rating, date, time;
    //cinema
    std::string cinemaName;
    int screenNumber;

public:
    MovieDetails() {
        movieID = 0;
        title = genre = duration = rating = time =
            cinemaName = date = "NULL";
        screenNumber = 0;
    }
    //movie details 

    bool setMovieID(const std::string& id) {
        if (!Validation::isValidID(id, "Movie ID"))
            return false;

        movieID = std::stoi(id);
        if (movieID < 0 || movieID > 10000) {
            Color::setRedTextColor();
            std::cout << "Error: Movie ID must be in between 1 and 9999.\n\n";
            Color::resetTextColor();
            return false;
        }
        return true;
    }

    bool setTitle(const std::string& temp) {
        if (Validation::isValidName(temp, "Movie Title")) {
            title = temp;
            return true;
        }
        else
            return false;
    }
    void setGenre(const std::string& g) { genre = g; }
    void setDuration(const std::string& d) { duration = d; }
    void setRating(const std::string& r) { rating = r; }

    //movie
    bool setCinemaName(const std::string& temp) {
        if (Validation::isValidName(temp, "Cinema Name")) {
            cinemaName = temp;
            return true;
        }
        else
            return false;
    }
    bool setScreenNumber(const std::string& temp) {
        if (Validation::isValidScreenNumber(temp)) {
            screenNumber = stoi(temp);
            return true;
        }
        else
            return false;

    }

    bool setMovieDate(const std::string& dates) {
        if (Validation::isValidDate(dates, "Movie Date")) {
            date = dates;
            return true;
        }
        else
            return false;
    }

    bool setMovieTime(const std::string& temp) {
        if (Validation::isValidTime(temp, date, "Movie Time")) {
            time = temp;
            return true;
        }
        else
            return false;
    }

    int getMovieID() 		  	  const { return movieID; }
    std::string getTitle()    	  const { return title; }
    std::string getGenre()    	  const { return genre; }
    std::string getDuration() 	  const { return duration; }
    std::string getRating()   	  const { return rating; }
    std::string getCinemaName()   const { return cinemaName; }
    int getScreenNumber() const { return screenNumber; }
    std::string getMovieDate()    const { return date; }
    std::string getMovieTime()    const { return time; }
};

class MovieInput {
    static MovieDetails m;
    std::string temp;

public:

    // Generic input helper taking a prompt and a pointer-to-member- setter function.
    static void inputGeneric(const std::string& prompt, bool (MovieDetails::* setter)(const std::string&)) {
        short int count = 0, max_tries = 5;
        while (true) {
            system("cls");
            Color::setCyanTextColor();
            std::cout << "----------------------------------------------------\n";
            std::cout << "                   Movie Details                    \n";
            std::cout << "----------------------------------------------------\n\n";
            Color::resetTextColor();
            std::cout << prompt;
            std::string input;
            getline(std::cin, input);
            if ((m.*setter)(input)) {
                Print::Saved();
                break;
            }
            else {
                count++;
                if (count >= max_tries) {
                    pause(30);
                }
                system("pause");
            }
        }
    }

    void inputMovieID() {
        inputGeneric("Enter Movie ID: ", &MovieDetails::setMovieID);
        std::cout << "ID: " << m.getMovieID() << std::endl << std::endl;

    }

    void inputMovieTitle() {
        inputGeneric("Enter Movie Title: ", &MovieDetails::setTitle);
        std::cout << "Title: " << m.getTitle() << std::endl << std::endl;
    }

    void inputMovieGenre() {
        short int count = 0, max_tries = 5;
        while (true) {
            system("cls");
            std::cout << "\n=====Movie details=====\n\n";
            Menu::DisplayMovieGenres();
            std::cout << "Select some genre (e.g. 1,4,7...etc): ";
            getline(std::cin, temp);
            bool valid = true;
            std::string genreList;
            std::string genreNames[19] = {
                "", "Action", "Adventure", "Comedy", "Drama", "Horror",
                "Science Fiction", "Romance", "Thriller", "Animation",
                "Fantasy", "Mystery", "Crime", "Musical", "Documentary",
                "Historical", "War", "Western", "Biography"
            };

            std::string num;
            for (size_t i = 0; i <= temp.length(); ++i) {
                if (i == temp.length() || temp[i] == ',') {
                    if (!num.empty()) {
                        int choice = std::stoi(num);
                        if (choice < 1 || choice > 18) {
                            valid = false;
                            Color::setRedTextColor();
                            std::cout << "Error: Genre number " << choice << " is out of range.\n";
                            Color::resetTextColor();
                            break;
                        }
                        if (!genreList.empty()) genreList += ",";
                        genreList += genreNames[choice];
                        num.clear();
                    }
                }
                else if (isdigit(temp[i])) {
                    num += temp[i];
                }
                else {
                    valid = false;
                    Print::Error("Invalid choice.");
                    system("pause");
                    break;
                }
            }

            if (valid && !genreList.empty()) {
                Color::setGreenTextColor();
                std::cout << "Selected Genres: " << genreList << "\n";
                Color::resetTextColor();
                m.setGenre(genreList);  // ? Save to object
                break;
            }
            else {
                count++;
                // If maximum tries reached, pause for 30 seconds and reset the counter
                if (count >= max_tries) {
                    Color::setRedTextColor();
                    std::cout << "Too many invalid attempts. Pausing for 30 seconds...\n";
                    Color::resetTextColor();
                    pause(30);
                    count = 0; // reset the counter after pause
                }
                // The loop continues for re-entry if invalid input was provided
            }
        }
    }

    void inputMovieDuration() {
        short int count = 0, max_tries = 5;
        system("cls");
        std::cout << "\n=====Movie details=====\n\n";
        Menu::DisplayMovieDurations();

        while (true) {
            std::cout << "Select movie duration (1-4): ";
            std::string temp;
            getline(std::cin, temp);

            // Check if the input is a single valid digit between '1' and '4'
            if (temp.length() != 1 || temp[0] < '1' || temp[0] > '4') {
                Color::setRedTextColor();
                std::cout << "Error: Invalid choice.\n";
                Color::resetTextColor();
                count++;
                if (count >= max_tries) {
                    Color::setRedTextColor();
                    std::cout << "Too many invalid attempts. Pausing for 30 seconds...\n";
                    Color::resetTextColor();
                    pause(30);
                    count = 0;
                }
                continue;
            }

            // If valid, map the input to the proper duration string.
            std::string durations[5] = {
                "", "40_min", "90-120_min", "120-150_min", "150_min"
            };
            int choice = temp[0] - '0';
            std::string selectedDuration = durations[choice];

            // Store the selected duration to the MovieDetails object.
            m.setDuration(selectedDuration);

            Color::setGreenTextColor();
            std::cout << "Selected Duration: " << selectedDuration << "\n";
            Color::resetTextColor();
            break;
        }
    }

    void inputMovieRating() {
        short int count = 0, max_tries = 5;
        system("cls");
        std::cout << "\n=====Movie details=====\n\n";
        Menu::DisplayMovieRatings();

        while (true) {
            std::cout << "Select movie rating (1-9): ";
            std::string temp;
            getline(std::cin, temp);

            // Validate input: exactly one digit between '1' and '9'
            if (temp.length() != 1 || temp[0] < '1' || temp[0] > '9') {
                Color::setRedTextColor();
                std::cout << "Error: Invalid choice.\n";
                Color::resetTextColor();
                count++;
                if (count >= max_tries) {
                    Color::setRedTextColor();
                    std::cout << "Too many invalid attempts. Pausing for 30 seconds...\n";
                    Color::resetTextColor();
                    pause(30);
                    count = 0;
                }
                continue;
            }

            // Map the valid input to the corresponding rating.
            std::string ratings[10] = {
                "",
                "G",
                "PG",
                "PG-13",
                "R",
                "NC-17",
                "U",
                "UA",
                "A",
                "Not_Rated"
            };

            int choice = temp[0] - '0';
            std::string selectedRating = ratings[choice];

            // Save the rating to the MovieDetails object.
            m.setRating(selectedRating);

            Color::setGreenTextColor();
            std::cout << "Selected Rating: " << selectedRating << "\n";
            Color::resetTextColor();
            break;
        }
    }

    void inputCinemaName() {
        inputGeneric("Enter Cinema Name: ", &MovieDetails::setCinemaName);

        std::cout << "Cinema Name: " << m.getCinemaName() << "\n\n";
    }

    void inputScreenNumber() {
        inputGeneric("Enter Screen Number: ", &MovieDetails::setScreenNumber);

        std::cout << "Screen Number: " << m.getScreenNumber() << "\n\n";
    }

    void inputMovieDate() {
        inputGeneric("Enter Movie Date: ", &MovieDetails::setMovieDate);

        std::cout << "Movie Date: " << m.getMovieDate() << "\n\n";
    }

    void inputMovieTime() {
        inputGeneric("Enter Movie Time: ", &MovieDetails::setMovieTime);

        std::cout << "Movie Time: " << m.getMovieTime() << "\n\n";
    }

    MovieDetails getMovieDeatails() {
        return m;
    }

    bool saveMovieDataOnFile() {
        if (m.getTitle() == "NULL") {
            Print::Error("Movie title is missing.");
            return false;
        }
        else if (m.getGenre() == "NULL") {
            Print::Error("Movie genre is missing.");
            return false;
        }
        else if (m.getDuration() == "NULL") {
            Print::Error("Movie duration is missing.");
            return false;
        }
        else if (m.getMovieDate() == "NULL") {
            Print::Error("Movie Date is missing.");
            return false;
        }
        else if (m.getMovieTime() == "NULL") {
            Print::Error("Movie Time is missing.");
            return false;
        }
        else if (m.getRating() == "NULL") {
            Print::Error("Movie rating is missing.");
            return false;
        }
        else if (m.getCinemaName() == "NULL") {
            Print::Error("Cinema name is missing.");
            return false;
        }
        else if (m.getScreenNumber() == 0) {
            Print::Error("Screen number is missing.");
            return false;
        }
        else {
            std::ofstream write("movies_details.txt", std::ios::app);
            write << m.getMovieID() << "|"
                << m.getTitle() << "|"
                << m.getGenre() << "|"
                << m.getDuration() << "|"
                << m.getMovieDate() << "|"
                << m.getMovieTime() << "|"
                << m.getRating() << "|"
                << m.getCinemaName() << "|"
                << m.getScreenNumber() << "\n";
            write.close();

            Color::setGreenTextColor();
            std::cout << "Saved movie and cinema to file.\n";
            Color::resetTextColor();
            return true;
        }
        return true;
    }
};
MovieDetails MovieInput::m;

class MovieFeatures {
public:
    static void add_movie() {
        MovieInput movie;
        movie.inputMovieID();
        system("pause");
        movie.inputMovieTitle();
        system("pause");
        movie.inputMovieGenre();
        system("pause");
        movie.inputMovieDuration();
        system("pause");
        movie.inputMovieDate();
        system("pause");
        movie.inputMovieTime();
        system("pause");
        movie.inputMovieRating();
        system("pause");
        movie.inputCinemaName();
        system("pause");
        movie.inputScreenNumber();

        movie.saveMovieDataOnFile();
        std::cout << "\n";
        system("pause");
    }

    static bool deleteMovie(const std::string& ID) {
        if (!Validation::isValidID(ID, "Movie ID")) {
            return false;
        }

        int movieID = std::stoi(ID);
        std::ifstream read("movies_details.txt");
        if (!read) {
            Color::setRedTextColor();
            std::cout << "Error: Movie File Not Found.\n\n";
            Color::resetTextColor();
            return false;
        }

        if (Validation::isFileEmpty(read, "movies_details")) {
            return false;
        }

        std::ofstream write("temp.txt");
        bool notFound = true;

        MovieRecord mr;
        std::string line = "";
        while (getline(read, line)) {
            std::istringstream in(line);
            getline(in, mr.ID, '|');
            getline(in, mr.title, '|');
            getline(in, mr.genre, '|');
            getline(in, mr.duration, '|');
            getline(in, mr.date, '|');
            getline(in, mr.time, '|');
            getline(in, mr.rating, '|');
            getline(in, mr.cinemaName, '|');
            getline(in, mr.screenNumber);
            if (std::stoi(mr.ID) == movieID) {
                notFound = false;
                continue; // skip writing this line (delete it)
            }

            write << mr.ID << "|" << mr.title << "|" << mr.genre << "|" << mr.duration << "|" << mr.date << "|"
                << mr.time << "|" << mr.rating << "|" << mr.cinemaName << "|" << mr.screenNumber << std::endl;
        }

        read.close();
        write.close();

        if (notFound) {
            Print::Error("Movie Not Found.");
            remove("temp.txt");
            return false;
        }

        if (std::remove("movies_details.txt") != 0 || std::rename("temp.txt", "movies_details.txt") != 0) {
            Print::Error("Updating Movie File.");
            return false;
        }

        Print::Success("Movie Deleted Successfully.");
        return true;
    }

    static void view_movies() {
        std::ifstream read("movies_details.txt");

        if (!read) {
            Color::setRedTextColor();
            std::cout << "Error: movies_details File Not Found.\n\n";
            Color::resetTextColor();
            return;
        }

        if (Validation::isFileEmpty(read, "movies_details")) {
            return;
        }


        Color::setCyanTextColor();
        std::cout << "\n------------------------ Movie Details ------------------------\n";
        Color::resetTextColor();

        Color::setGrayTextColor();
        std::cout << "\nFormat: ID  Title (Genre | Duration | Date | Time | Rating | Cinema Name | Screen Number)\n";
        Color::resetTextColor();

        Color::setCyanTextColor();
        std::cout << "--------------------------------------------------------------\n";
        Color::resetTextColor();
        int count = 0;
        MovieRecord mr;
        std::string line = "";
        while (getline(read, line)) {
            std::istringstream in(line);
            getline(in, mr.ID, '|');
            getline(in, mr.title, '|');
            getline(in, mr.genre, '|');
            getline(in, mr.duration, '|');
            getline(in, mr.date, '|');
            getline(in, mr.time, '|');
            getline(in, mr.rating, '|');
            getline(in, mr.cinemaName, '|');
            getline(in, mr.screenNumber);
            count++;

            Color::setLightYellowTextColor();
            std::cout << mr.ID << ". ";
            Color::resetTextColor();
            std::cout << mr.title; // Title 
            Color::setGrayTextColor();
            std::cout << " (";
            std::cout << mr.genre; // Genre
            std::cout << " | ";
            std::cout << mr.duration; // Duration
            std::cout << " | ";
            std::cout << mr.date; // Date
            std::cout << " | ";
            std::cout << mr.time; // Time
            std::cout << " | ";
            std::cout << mr.rating; // Rating
            std::cout << " | ";
            std::cout << mr.cinemaName; // Cinema Name
            std::cout << " | ";

            std::cout << mr.screenNumber; // Screen Number
            Color::resetTextColor();

            std::cout << ")\n";



            Color::resetTextColor();
            if (count % 10 == 0) {
                Color::setCyanTextColor();
                std::cout << "\n--------------------------------------------------------------\n";
                Color::resetTextColor();
            }
            std::cout << std::endl;
        }

        read.close();
    }

    static bool searchMovie(const std::string& ID) {
        if (!Validation::isValidID(ID, "")) {
            return false;
        }

        int movieID = std::stoi(ID);
        std::ifstream read("movies_details.txt");

        if (!read) {
            Color::setRedTextColor();
            std::cout << "Error: movies_details File Not Found.\n\n";
            Color::resetTextColor();
            return false;
        }

        if (Validation::isFileEmpty(read, "movies_details")) {
            return false;
        }

        bool notFound = true;
        std::string line = "";
        /* Expected Data Format:
           Format: 0. Movie ID (int) | 1. Title (string) | 2. Genre (string) | 3. Duration (string) | 4. Date (string)
                   5. Rating (string) | 6. Cinema Name (string) | 7. Screen Number (string) */
        MovieRecord mr;
        while (getline(read, line)) {
            std::istringstream in(line);
            getline(in, mr.ID, '|');
            getline(in, mr.title, '|');
            getline(in, mr.genre, '|');
            getline(in, mr.duration, '|');
            getline(in, mr.date, '|');
            getline(in, mr.time, '|');
            getline(in, mr.rating, '|');
            getline(in, mr.cinemaName, '|');
            getline(in, mr.screenNumber);
            if (std::stoi(mr.ID) == movieID) {
                notFound = false;

                Color::setCyanTextColor();
                std::cout << "\n-------------------------------------------------\n";
                std::cout << "                  Movie Details                 \n";
                std::cout << "-------------------------------------------------\n";
                Color::resetTextColor();

                std::cout << "Movie ID: " << mr.ID << "\n";
                std::cout << "Title: " << mr.title << "\n";
                std::cout << "Genre: " << mr.genre << "\n";
                std::cout << "Duration: " << mr.duration << "\n";
                std::cout << "Date: " << mr.date << "\n";
                std::cout << "Time: " << mr.time << "\n";
                std::cout << "Rating: " << mr.rating << "\n";
                std::cout << "Cinema: " << mr.cinemaName << "\n";
                std::cout << "Screen Number: " << mr.screenNumber << "\n";
                Color::setCyanTextColor();
                std::cout << "-------------------------------------------------\n";
                Color::resetTextColor();
            }
        }

        read.close();

        if (notFound) {
            Color::setRedTextColor();
            std::cout << "Movie Not Found.\n\n";
            Color::resetTextColor();
            return false;
        }
        return true;
    }

    static void userSearchMovie() {
        std::string inputMovieDate = "";
        short count = 0, max_try = 5;
        while (true) {
            system("cls");
            Color::setCyanTextColor();
            std::cout << "----------------------------------------------------\n";
            std::cout << "             Movie Searching Interface              \n";
            std::cout << "----------------------------------------------------\n\n";
            Color::resetTextColor();
            std::cout << "Enter Movie Date: ";
            getline(std::cin, inputMovieDate);
            if (Validation::isValidDateFormat(inputMovieDate, "Movie Date")) {
                break;
            }
            else {
                count++;
                if (count >= max_try) {
                    pause(30);
                }
                system("pause");
            }
            Color::setLightYellowTextColor();
            std::cout << "\nRe-enter Movie Date?\n";
            Color::resetTextColor();
            std::cout << "Enter Yes or No (No as Default): ";
            getline(std::cin, inputMovieDate);
            if (inputMovieDate != "Yes" && inputMovieDate != "yes") {
                return;
            }
        }
        std::ifstream read("movies_details.txt");

        if (!read) {
            Color::setRedTextColor();
            std::cout << "Error: movies_details File Not Found.\n\n";
            Color::resetTextColor();
            return;
        }

        if (Validation::isFileEmpty(read, "movies_details")) {
            return;
        }

        bool notFound = true;
        std::string line = "";
        /* Expected Data Format:
           Format: 0. Movie ID (int) | 1. Title (string) | 2. Genre (string) | 3. Duration (string) | 4. Date (string) |
                   5. Time (string) | 6. Rating (string) | 7. Cinema Name (string) | 8. Screen Number (string) */
        MovieRecord mr;
        while (getline(read, line)) {
            std::istringstream in(line);
            getline(in, mr.ID, '|');
            getline(in, mr.title, '|');
            getline(in, mr.genre, '|');
            getline(in, mr.duration, '|');
            getline(in, mr.date, '|');
            getline(in, mr.time, '|');
            getline(in, mr.rating, '|');
            getline(in, mr.cinemaName, '|');
            getline(in, mr.screenNumber);
            if (mr.date == inputMovieDate) {
                notFound = false;

                Color::setCyanTextColor();
                std::cout << "\n-------------------------------------------------\n";
                std::cout << "                  Movie Details                 \n";
                std::cout << "-------------------------------------------------\n";
                Color::resetTextColor();

                std::cout << "Movie ID: " << mr.ID << "\n";
                std::cout << "Title: " << mr.title << "\n";
                std::cout << "Genre: " << mr.genre << "\n";
                std::cout << "Duration: " << mr.duration << "\n";
                std::cout << "Date: " << mr.date << "\n";
                std::cout << "Time: " << mr.time << "\n";
                std::cout << "Rating: " << mr.rating << "\n";
                std::cout << "Cinema: " << mr.cinemaName << "\n";
                std::cout << "Screen Number: " << mr.screenNumber << "\n";
                Color::setCyanTextColor();
                std::cout << "-------------------------------------------------\n";
                Color::resetTextColor();
            }
        }

        read.close();

        if (notFound) {
            Color::setRedTextColor();
            std::cout << "Movie Not Found.\n\n";
            Color::resetTextColor();
            return;
        }
        return;
    }

    static MovieDetails getMovieObject(const std::string& movieID) {
        MovieDetails m;

        MovieRecord mr;
        std::string line = "";
        /* Expected Data Format:
           Format: 0. Movie ID (int) | 1. Title (string) | 2. Genre (string) | 3. Duration (string) | 4. Date (string)
                   5. Time (string) 6. Rating (string) | 7. Cinema Name (string) | 8. Screen Number (string) */
        std::ifstream read("movies_details.txt");

        while (getline(read, line)) {
            std::istringstream in(line);
            getline(in, mr.ID, '|');
            getline(in, mr.title , '|');
            getline(in, mr.genre, '|');
            getline(in, mr.duration, '|');
            getline(in, mr.date, '|');
            getline(in, mr.time, '|');
            getline(in, mr.rating, '|');
            getline(in, mr.cinemaName, '|');
            getline(in, mr.screenNumber);
            if (mr.ID == movieID) {
                m.setMovieID(mr.ID);
                m.setTitle(mr.title);
                m.setGenre(mr.genre);
                m.setDuration(mr.duration);
                m.setMovieDate(mr.date);
                m.setMovieTime(mr.time);    
                m.setRating(mr.rating);
                m.setCinemaName(mr.cinemaName);
                m.setScreenNumber(mr.screenNumber);
                break;
            }
        }

        read.close();
        return m;
    }

};

class MovieTicket {
public:

    static void displayTicket(const MovieTicketRecord& mr) {
        Color::setCyanTextColor();
        std::cout << "------------------ Movie Ticket --------------------\n\n";
        Color::resetTextColor();

        std::cout << "Customer Name: " << mr.username << "\n\n";

        std::cout << "Title: " << mr.title << "\n";
        std::cout << "Genre: " << mr.genre << "\n";
        std::cout << "Duration: " << mr.duration << "\n";
        std::cout << "Date: " << mr.date << "\n";
        std::cout << "Time: " << mr.time << "\n";
        std::cout << "Cinema: " << mr.cinemaName << "\n";
        std::cout << "Screen Number: " << mr.screenNumber << "\n\n";

        Color::setCyanTextColor();
        std::cout << "----------------------------------------------------\n\n";
        Color::resetTextColor();
    }

    static void printTicket(const MovieDetails& m, const std::string& username) {
        system("cls");

        Color::setCyanTextColor();
        std::cout << "----------------------------------------------------\n";
        std::cout << "                   Movie Ticket                     \n";
        std::cout << "----------------------------------------------------\n\n";
        Color::resetTextColor();

        std::cout << "Customer Name: " << username << "\n\n";

        std::cout << "Title: " << m.getTitle() << "\n";
        std::cout << "Genre: " << m.getGenre() << "\n";
        std::cout << "Duration: " << m.getDuration() << "\n";
        std::cout << "Date: " << m.getMovieDate() << "\n";
        std::cout << "Time: " << m.getMovieTime() << "\n";
        std::cout << "Cinema: " << m.getCinemaName() << "\n";
        std::cout << "Screen Number: " << m.getScreenNumber() << "\n\n";

        Color::setCyanTextColor();
        std::cout << "----------------------------------------------------\n\n";
        Color::resetTextColor();
    }

    static bool saveTicket(const MovieDetails& m, const std::string& userName) {
        std::ifstream checkAlreadyBook("Movie_Booking.txt");
        if (checkAlreadyBook.fail()) {
            Print::Error("Unable to open Movie_Booking File.");
            return false;
        }
        std::string line = "";
        bool found = false;
        MovieTicketRecord mr;
        while (getline(checkAlreadyBook, line)) {
            std::istringstream in(line);
            getline(in, mr.username, '|');
            getline(in, mr.ID, '|'); 
            getline(in, mr.title, '|');
            getline(in, mr.genre, '|');
            getline(in, mr.duration, '|');
            getline(in, mr.date, '|');
            getline(in, mr.time, '|');
            getline(in, mr.rating, '|');
            getline(in, mr.cinemaName, '|');
            getline(in, mr.screenNumber);
            if (std::stoi(mr.ID) == m.getMovieID() && userName == mr.username) {
                found = true;
            }
        }
        checkAlreadyBook.close();
        if (found) {
            Print::Error("User is already booked.");
            return false;
        }
        Color::setLightYellowTextColor();
        std::cout << "Confirm Book?\n";
        Color::resetTextColor();
        std::cout << "Enter Yes or No (No as Default): ";
        getline(std::cin, line);
        if (line != "Yes" && line != "yes") {
            Print::Error("Booking Cancelled!");
            return false;
        }
        PaymentDetails userPayment;
        userPayment = PaymentInterface::makePayment();

        std::ofstream writeTicket("Movie_Booking.txt", std::ios::app);
        if (writeTicket.fail()) {
            Print::Error("Unable to open Movie_Booking File");
            return false;
        }
        writeTicket << userName << "|" << m.getMovieID() << "|" << m.getTitle() << "|"
            << m.getGenre() << "|" << m.getDuration() << "|" << m.getMovieDate() << "|"
            << m.getMovieTime() << "|" << m.getRating() << "|" << m.getCinemaName() << "|"
            << m.getScreenNumber() << std::endl;
        writeTicket.close();
        return true;
    }

    static void bookTicket(const std::string& ID, const std::string& userName) {
        system("cls");
        Color::setCyanTextColor();
        std::cout << "----------------------------------------------------\n";
        std::cout << "               Movie Ticket Booking                 \n";
        std::cout << "----------------------------------------------------\n\n";
        Color::resetTextColor();

        MovieDetails movie;
        movie = MovieFeatures::getMovieObject(ID);
        if(saveTicket(movie, userName))
            printTicket(movie, userName);
        system("pause");
    }

    static void cancelTicket(const std::string& userName) {
        std::string movieID = "";
        short count = 0, max_try = 5;
        while (true) {
            system("cls");
            Color::setCyanTextColor();
            std::cout << "----------------------------------------------------\n";
            std::cout << "        Movie Ticket Cancellation Interface         \n";
            std::cout << "----------------------------------------------------\n\n";
            Color::resetTextColor();
            std::cout << "Enter Movie ID: ";
            getline(std::cin, movieID);
            if (Validation::isValidID(movieID, "Movie ID")) {
                break;
            }
            else {
                count++;
                if (count >= max_try) {
                    pause(30);
                }
                system("pause");
            }
            Color::setLightYellowTextColor();
            std::cout << "\nRe-enter Movie ID?\n";
            std::cout << "Enter Yes or No (No as Default): ";
            getline(std::cin, movieID);
            if (movieID != "Yes" && movieID != "yes") {
                break;
            }
        }
        std::ifstream readMovieBookingData("Movie_Booking.txt");
        if (readMovieBookingData.fail()) {
            Print::Error("Unable to open Movie_Booking File.");
            return;
        }
        std::string line = "", keptRecord = "";
        bool found = false;
        MovieTicketRecord mr;
        while (getline(readMovieBookingData, line)) {
            std::istringstream in(line);
            getline(in, mr.username, '|');
            getline(in, mr.ID, '|');
            getline(in, mr.title, '|');
            getline(in, mr.genre, '|');
            getline(in, mr.duration, '|');
            getline(in, mr.date, '|');
            getline(in, mr.time, '|');
            getline(in, mr.rating, '|');
            getline(in, mr.cinemaName, '|');
            getline(in, mr.screenNumber);
            if (mr.ID == movieID && userName == mr.username) {
                found = true;
                continue;
            }
            keptRecord += mr.username + "|" + mr.ID + "|" + mr.title + "|"
                + mr.genre + "|" + mr.duration + "|" + mr.date + "|"
                + mr.time + "|" + mr.rating + "|" + mr.cinemaName + "|"
                + mr.screenNumber + "\n";
        }
        readMovieBookingData.close();
        if (!found) {
            Print::Error("No Movie Ticket Record Found.");
            return;
        }
        Color::setLightYellowTextColor();
        std::cout << "\nConfirm Ticket Deletion?\n";
        Color::resetTextColor();
        std::cout << "Enter Yes or No (No as Default): ";
        getline(std::cin, line);
        if (line != "Yes" && line != "yes") {
            Print::Error("Ticket Deletion Cancelled!");
            return;
        }
        std::ofstream writeMovieBookingData("Movie_Booking.txt", std::ios::trunc);
        if (writeMovieBookingData.fail()) {
            Print::Error("Unable to open Movie_Booking File.");
            return;
        }
        writeMovieBookingData << keptRecord;
        Print::Success("Ticket Deleted.");
        return;
    }

    static void userViewTicketHistory(const std::string& userName) {
        std::ifstream readTicketHistory("Movie_Booking.txt");
        if (readTicketHistory.fail()) {
            Print::Error("Unable to open Movie_Booking File.");
            return;
        }
        else if (Validation::isFileEmpty(readTicketHistory, "Movie_Booking")) {
            return;
        }
        std::string line = "";
        bool found = false;
        MovieTicketRecord mr;
        while (getline(readTicketHistory, line)) {
            std::istringstream in(line);
            getline(in, mr.username, '|');
            getline(in, mr.ID, '|');
            getline(in, mr.title, '|');
            getline(in, mr.genre, '|');
            getline(in, mr.duration, '|');
            getline(in, mr.date, '|');
            getline(in, mr.time, '|');
            getline(in, mr.rating, '|');
            getline(in, mr.cinemaName, '|');
            getline(in, mr.screenNumber);
            if (userName == mr.username) {
                found = true;
                displayTicket(mr);
            }
        }
        readTicketHistory.close();
        if (!found) {
            Print::Error("No Record Found.");
            return;
        }
    }

    static void adminViewTicketHistory() {
        std::ifstream readTicketHistory("Movie_Booking.txt");
        if (readTicketHistory.fail()) {
            Print::Error("Unable to open Movie_Booking File.");
            return;
        }
        else if (Validation::isFileEmpty(readTicketHistory, "Movie_Booking")) {
            return;
        }

        Color::setCyanTextColor();
        std::cout << "----------------------------------------------------\n";
        std::cout << "                Movie Ticket History                \n";
        std::cout << "----------------------------------------------------\n\n";
        Color::resetTextColor();

        std::string line = "";
        MovieTicketRecord mr;
        while (getline(readTicketHistory, line)) {
            std::istringstream in(line);
            getline(in, mr.username, '|');
            getline(in, mr.ID, '|');
            getline(in, mr.title, '|');
            getline(in, mr.genre, '|');
            getline(in, mr.duration, '|');
            getline(in, mr.date, '|');
            getline(in, mr.time, '|');
            getline(in, mr.rating, '|');
            getline(in, mr.cinemaName, '|');
            getline(in, mr.screenNumber);
            displayTicket(mr);
        }
        readTicketHistory.close();
    }

    static void adminViewTicketHistoryOfAUser() {
        std::string userName = "";
        std::string response = "";
        short count = 0, max_try = 5;
        while (true) {
            system("cls");
            Color::setCyanTextColor();
            std::cout << "----------------------------------------------------\n";
            std::cout << "                Movie Ticket History                \n";
            std::cout << "----------------------------------------------------\n\n";
            Color::resetTextColor();
            std::cout << "Enter Username: ";
            getline(std::cin, userName);
            if (Validation::isValidUsername(userName)) {
                break;
            }
            else {
                count++;
                if (count >= max_try) {
                    pause(30);
                }
                system("pause");
            }
            Color::setLightYellowTextColor();
            std::cout << "\nRe-enter Username?\n";
            std::cout << "Enter Yes or No (No as Default): ";
            getline(std::cin, response);
            if (response != "Yes" && response != "yes") {
                // If admin chooses not to re-enter, exit the function.
                return;
            }
        }

        std::ifstream readTicketHistory("Movie_Booking.txt");
        if (readTicketHistory.fail()) {
            Print::Error("Unable to open Movie_Booking File.");
            return;
        }
        else if (Validation::isFileEmpty(readTicketHistory, "Movie_Booking")) {
            return;
        }

        std::string line = "";
        MovieTicketRecord mr;
        bool found = false;
        while (getline(readTicketHistory, line)) {
            std::istringstream in(line);
            getline(in, mr.username, '|');
            getline(in, mr.ID, '|');
            getline(in, mr.title, '|');
            getline(in, mr.genre, '|');
            getline(in, mr.duration, '|');
            getline(in, mr.date, '|');
            getline(in, mr.time, '|');
            getline(in, mr.rating, '|');
            getline(in, mr.cinemaName, '|');
            getline(in, mr.screenNumber);
            if (userName == mr.username) {
                found = true;
                displayTicket(mr);
            }
        }
        readTicketHistory.close();
        if (!found) {
            Print::Error("No Record Found for the User.");
            return;
        }
    }
};

class MovieInterface {
public:
    static void adminMovieOptions() {
        while (true) {
            system("cls");
            Color::setCyanTextColor();
            std::cout << "----------------------------------------------------\n";
            std::cout << "                     Admin Menu                     \n";
            std::cout << "----------------------------------------------------\n\n";
            Color::resetTextColor();
            std::string choice = "\0";
            std::cout << "1. Add Movie" << std::endl;
            std::cout << "2. Remove Movie" << std::endl;
            std::cout << "3. View Movie" << std::endl;
            std::cout << "4. Search Movie" << std::endl;
            std::cout << "5. View Ticket History" << std::endl;
            std::cout << "6. View Ticket History of a User" << std::endl;
            std::cout << "7. Exit" << std::endl;
            std::cout << "Enter your choice: ";
            getline(std::cin, choice);

            if (choice == "1") {
                system("cls");
                Color::setCyanTextColor();
                std::cout << "----------------------------------------------------\n";
                std::cout << "                 Add Movie Interface                \n";
                std::cout << "----------------------------------------------------\n\n";
                Color::resetTextColor();
                MovieFeatures::add_movie();
            }
            else if (choice == "2") {
                while (true) {
                    system("cls");
                    Color::setCyanTextColor();
                    std::cout << "----------------------------------------------------\n";
                    std::cout << "              Movie Deletion Interface              \n";
                    std::cout << "----------------------------------------------------\n\n";
                    Color::resetTextColor();
                    std::string input;
                    std::cout << "Enter Movie ID to Delete:";
                    getline(std::cin, input);
                    if (MovieFeatures::deleteMovie(input)) {
                        system("pause");
                        break;
                    }
                    Color::setLightYellowTextColor();
                    std::cout << "\nRe-enter Movie ID?" << std::endl;
                    Color::resetTextColor();
                    std::cout << "Enter Yes or No (Default No): ";
                    getline(std::cin, input);
                    if (input != "Yes" && input != "yes") {
                        break;
                    }
                }
            }
            else if (choice == "3") {
                system("cls");
                MovieFeatures::view_movies();
                system("pause");
            }
            else if (choice == "4") {
                while (true) {
                    system("cls");
                    Color::setCyanTextColor();
                    std::cout << "----------------------------------------------------\n";
                    std::cout << "               Movie Search Interface               \n";
                    std::cout << "----------------------------------------------------\n\n";
                    Color::resetTextColor();
                    std::string input;
                    std::cout << "Enter Movie ID to Search:";
                    getline(std::cin, input);
                    if (MovieFeatures::searchMovie(input)) {
                        system("pause");
                        break;
                    }
                    Color::setLightYellowTextColor();
                    std::cout << "\nRe-enter Movie ID?" << std::endl;
                    Color::resetTextColor();
                    std::cout << "Enter Yes or No (Default No): ";
                    getline(std::cin, input);
                    if (input != "Yes") {
                        break;
                    }
                }
            }

            else if (choice == "5") {       //View Ticket History
                system("cls");
                MovieTicket::adminViewTicketHistory();
                system("pause");

            }

            else if (choice == "6") {       //View Ticket History of a User
                system("cls");
                MovieTicket::adminViewTicketHistoryOfAUser();
                system("pause");

            }

            else if (choice == "7") {
                Color::setLightMagentaTextColor();
                std::cout << "\nExiting Movie Admin Interface....\n\n";
                Color::resetTextColor();
                system("pause");
                return;
            }
            else {
                system("cls");
                Print::Error("Invalid Choice");
                system("pause");

            }
        }
    }

    static void userMovieOptions(const std::string& userName) {
        while (true) {
            system("cls");
            Color::setCyanTextColor();
            std::cout << "----------------------------------------------------\n";
            std::cout << "                     User Menu                      \n";
            std::cout << "----------------------------------------------------\n\n";
            Color::resetTextColor();
            std::string choice = "\0";
            std::cout << "1. View Available Movies" << std::endl;
            std::cout << "2. Search Movie" << std::endl;
            std::cout << "3. Book Movie" << std::endl;
            std::cout << "4. Cancel Movie Ticket" << std::endl;
            std::cout << "5. View Tickets History" << std::endl;
            std::cout << "6. Exit" << std::endl;
            std::cout << "Enter your choice : ";
            getline(std::cin, choice);

            if (choice == "1") {
                system("cls");
                MovieFeatures::view_movies();
                system("pause");
            }

            else if (choice == "2") {       //Select Movie
                MovieFeatures::userSearchMovie();
                system("pause");
            }

            else if (choice == "3") {       //Book Ticket
                while (true) {
                    system("cls");
                    std::string input;
                    Color::setCyanTextColor();
                    std::cout << "----------------------------------------------------\n";
                    std::cout << "               Movie Ticket Booking                 \n";
                    std::cout << "----------------------------------------------------\n\n";
                    Color::resetTextColor();
                    std::cout << "Enter Movie ID: ";
                    std::string movieID;
                    getline(std::cin, movieID);
                    if (MovieFeatures::searchMovie(movieID)) {

                        while (true) {
                            std::cout << "Do you want to book ticket for this movie (Yes or No): ";
                            std::string choice;
                            getline(std::cin, choice);

                            if (choice == "Yes" || choice == "yes") {
                                MovieTicket::bookTicket(movieID, userName);
                                break;
                            }
                            else if (choice == "No" || choice == "no") {
                                break;
                            }
                            else {
                                Color::setRedTextColor();
                                std::cout << "Error: Invalid Choice\n";
                                Color::resetTextColor();
                            }
                        }

                    }
                    Color::setLightYellowTextColor();
                    std::cout << "\nRe-enter Movie ID?" << std::endl;
                    Color::resetTextColor();
                    std::cout << "Enter Yes or No (Default No): ";
                    getline(std::cin, input);
                    if (input == "Yes" || input == "yes") {
                        continue;
                    }
                    else
                        break;
                }
            }

            else if (choice == "4") {       //Cancel Ticket
                MovieTicket::cancelTicket(userName);
                system("pause");

            }

            else if (choice == "5") {       //View Ticket History
                system("cls");
                MovieTicket::userViewTicketHistory(userName);
                system("pause");

            }

            else if (choice == "6") {
                Color::setLightMagentaTextColor();
                std::cout << "\nExiting Movie User Interface....\n\n";
                Color::resetTextColor();
                system("pause");
                return;
            }
            else {
                system("cls");
                Print::Error("Invalid Choice");
                system("pause");
            }

        }
    }

};

class UserDetails {
private:
    std::string firstName;
    std::string lastName;
    std::string emailAddress;
    std::string mobilePhoneNumber;
    std::string username;
    std::string password;

public:
    // Default Constructor
    UserDetails()
        : firstName("NULL"), lastName("NULL"),
        emailAddress("NULL"), mobilePhoneNumber("NULL"),
        username("NULL"), password("NULL") {
    }

    // Mutators
    bool setFirstName(const std::string& temp) {
        if (Validation::isValidName(temp, "First Name")) {
            firstName = temp;
            return true;
        }
        return false;
    }

    bool setLastName(const std::string& temp) {
        if (Validation::isValidName(temp, "Last Name")) {
            lastName = temp;
            return true;
        }
        return false;
    }

    bool setEmail(std::string& temp) {
        if (!Validation::isValidEmail(temp))
            return false;
        if (!Validation::isUserDuplicateData(temp))
            return false;

        emailAddress = temp;
        return true;
    }

    bool setMobilePhoneNumber(const std::string& temp) {
        if (!Validation::isValidPhoneNumber(temp, "Phone Number"))
            return false;
        if (!Validation::isUserDuplicateData(temp))
            return false;

        mobilePhoneNumber = temp;
        return true;
    }

    bool setUsername(const std::string& temp) {
        if (!Validation::isValidUsername(temp))
            return false;
        if (!Validation::isUserDuplicateData(temp))
            return false;

        username = temp;
        return true;
    }

    bool setPassword(const std::string& temp) {
        if (!Validation::isValidPassword(temp))
            return false;

        password = temp;
        return true;
    }

    // Accessors
    std::string getFirstName() const { return firstName; }
    std::string getLastName() const { return lastName; }
    std::string getEmail() const { return emailAddress; }
    std::string getMobilePhoneNumber() const { return mobilePhoneNumber; }
    std::string getUsername() const { return username; }
    std::string getPassword() const { return password; }
};

class UserInputs {
private:
    UserDetails u;
    std::string temp;
public:


    void inputFirstName() {
        while (true) {
            std::cout << "Enter First Name: ";
            std::getline(std::cin, temp);
            if (u.setFirstName(temp)) {
                Color::setGreenTextColor();
                std::cout << "Saved\n";
                Color::resetTextColor();
                break;
            }
        }
        std::cout << "First Name: " << u.getFirstName() << std::endl << std::endl;
    }

    void inputLastName() {
        temp.clear();
        while (true) {
            std::cout << "Enter Last Name: ";
            std::getline(std::cin, temp);

            if (u.setLastName(temp)) {
                Color::setGreenTextColor();
                std::cout << "Saved\n";
                Color::resetTextColor();
                break;
            }
        }
        std::cout << "Last Name: " << u.getLastName() << std::endl << std::endl;
    }

    void inputUserName() {
        temp.clear();
        while (true) {
            std::cout << "Enter Username: ";
            getline(std::cin, temp);

            if (u.setUsername(temp)) {
                Color::setGreenTextColor();
                std::cout << "Saved\n";
                Color::resetTextColor();
                break;
            }

        }
        std::cout << "Username: " << u.getUsername() << std::endl << std::endl;
    }

    void inputEmail() {
        temp.clear();
        while (true) {
            std::cout << "Enter Email: ";
            std::getline(std::cin, temp);

            if (u.setEmail(temp)) {
                Color::setGreenTextColor();
                std::cout << "Saved\n";
                Color::resetTextColor();
                break;
            }
        }
        std::cout << "Email: " << u.getEmail() << std::endl << std::endl;
    }

    void inputPhoneNumber() {
        temp.clear();
        while (true) {
            std::cout << "Enter Mobile Phone Number: ";
            std::getline(std::cin, temp);

            if (u.setMobilePhoneNumber(temp)) {
                Color::setGreenTextColor();
                std::cout << "Saved\n";
                Color::resetTextColor();
                break;
            }
        }
        std::cout << "Mobile Phone Number: " << u.getMobilePhoneNumber() << std::endl << std::endl;
    }

    void inputPassword() {
        char ch = '\0';
        while (true) {
            std::cout << "Enter Password: ";
            std::string password = "";
            char ch;
            while ((ch = _getch()) != '\r') {  // Enter key
                if (ch == '\b') {              // Backspace
                    if (!password.empty()) {
                        password.pop_back();
                        std::cout << "\b \b";
                    }
                }
                else {
                    password += ch;
                    std::cout << '*';
                }
            }
            std::cout << "\n";

            if (u.setPassword(password)) {
                Color::setGreenTextColor();
                std::cout << "Saved\n";
                Color::resetTextColor();
                break;
            }
            else {
            }

            continue;
        }
    }

    bool inputConfirmedPassword() {
        temp.clear();
        while (true) {
            temp.clear();
            std::cout << "Confirm Password: ";
            char ch;
            while ((ch = _getch())) {
                if (ch == '\r') {
                    std::cout << std::endl;
                    break;
                }
                else if (ch == '\b' && !temp.empty()) { // Handle backspace
                    std::cout << "\b \b";
                    temp.pop_back();
                }
                else {
                    temp += ch;
                    std::cout << "*";
                }
            }
            std::cout << std::endl;

            if (temp == u.getPassword()) {
                Color::setGreenTextColor();
                std::cout << "Password Confirmed!\n";
                Color::resetTextColor();
                return true;
            }
            else {
                Color::setRedTextColor();
                std::cout << "Error: Passwords do not match. Try again.\n\n";
                Color::resetTextColor();
                return false;
            }
        }
    }

    void displayUserData() {
        Color::setCyanTextColor();
        std::cout << "----------------------------------------------------\n";
        std::cout << "                   User Details                     \n";
        std::cout << "----------------------------------------------------\n\n";
        Color::resetTextColor();
        std::cout << "First Name: " << u.getFirstName() << "\n";
        std::cout << "Last Name: " << u.getLastName() << "\n";
        std::cout << "Email: " << u.getEmail();
        std::cout << "Mobile: " << u.getMobilePhoneNumber() << "\n";
        std::cout << "Username: " << u.getUsername() << "\n";
        std::cout << "Password: " << u.getPassword() << "\n";

    }

    UserDetails GetUserData() {
        return u;
    }

    bool saveUserDataOnFile() {
        if (u.getFirstName() == "NULL") {
            std::cout << "First name is missing.\n";
            return false;
        }

        else if (u.getLastName() == "NULL") {
            std::cout << "Last name is missing.\n";
            return false;
        }

        else if (u.getEmail() == "NULL") {
            std::cout << "Email is missing.\n";
            return false;
        }

        else if (u.getMobilePhoneNumber() == "NULL") {
            std::cout << "Phone Number is missing.\n";
            return false;
        }

        else if (u.getUsername() == "NULL") {
            std::cout << "Username is missing.\n";
            return false;
        }

        else if (u.getPassword() == "NULL") {
            std::cout << "Password name is missing.\n";
            return false;
        }

        else {
            std::ofstream write("UserData.txt", std::ios::app);

            write << u.getUsername() << "|" << u.getPassword() << "|" << u.getFirstName() << "|" << u.getLastName()
                << "|" << u.getEmail() << "|" << u.getMobilePhoneNumber() << "\n";

            write.close();
            Color::setGreenTextColor();
            std::cout << "Saved on file.\n\n";
            Color::resetTextColor();
            system("pause");
            return true;
        }
    }
};

class Login {
public:
    static void signUp() {
        UserInputs userInput;
        Color::setCyanTextColor();
        std::cout << "----------------------------------------------------\n";
        std::cout << "                      Sign Up                       \n";
        std::cout << "----------------------------------------------------\n\n";
        Color::resetTextColor();

        userInput.inputFirstName();
        userInput.inputLastName();
        userInput.inputUserName();
        userInput.inputEmail();
        userInput.inputPhoneNumber();
        while (true) {
            userInput.inputPassword();
            if (userInput.inputConfirmedPassword()) {
                break;
            }
        }

        UserDetails userDetails = userInput.GetUserData();
        if (userInput.saveUserDataOnFile()) {
            system("cls");
            Color::setGreenTextColor();
            std::cout << "Account created successfully.\n"
                << "Welcome, " << userDetails.getFirstName() << "!\n\n";
            Color::resetTextColor();
        }
        else {
            Color::setRedTextColor();
            std::cout << "Error: Could not save user data. Please ensure all fields are correctly filled.\n\n";
            Color::resetTextColor();
        }
    }

    bool login(const std::string& temp1, const std::string& temp2) {
        std::ifstream read("UserData.txt");
        std::string tempDetails[6];
        std::string line = "";
        // file format: username, password, firstname, lastname, email, phone
        while (getline(read, line)) {
            std::istringstream in(line);
            getline(in, tempDetails[0], '|');
            getline(in, tempDetails[1], '|');
            getline(in, tempDetails[2], '|');
            getline(in, tempDetails[3], '|');
            getline(in, tempDetails[4], '|');
            getline(in, tempDetails[5]);
            if (temp2 == tempDetails[1] &&
                (temp1 == tempDetails[0] ||
                    temp1 == tempDetails[4] ||
                    temp1 == tempDetails[5])) {
                Color::setGreenTextColor();
                std::cout << "\nCredentials matched.\n";
                Color::resetTextColor();
                return true;
            }
        }
        std::cout << "User not found.\n";
        return false;
    }

    bool adminLogin(const std::string& temp1, const std::string& temp2) {
        std::ifstream read("AdminData.txt");
        std::string tempDetails[6];
        std::string line = "";
        // file format: username, password, firstname, lastname, email, phone
        while (getline(read, line)) {
            std::istringstream in(line);
            getline(in, tempDetails[0], '|');
            getline(in, tempDetails[1], '|');
            getline(in, tempDetails[2], '|');
            getline(in, tempDetails[3], '|');
            getline(in, tempDetails[4], '|');
            getline(in, tempDetails[5]);
            if (temp2 == tempDetails[1] &&
                (temp1 == tempDetails[0] ||
                    temp1 == tempDetails[4] ||
                    temp1 == tempDetails[5])) {
                Color::setGreenTextColor();
                std::cout << "\nCredentials matched.\n";
                Color::resetTextColor();
                return true;
            }
        }
        std::cout << "User not found.\n";
        return false;
    }
};

class Interface {
public:
    static void adminInteface() {
        while (true) {
            system("cls");
            std::string choice;
            Color::setCyanTextColor();
            std::cout << "----------------------------------------------------\n";
            std::cout << "                  Admin Interface                   \n";
            std::cout << "----------------------------------------------------\n\n";
            Color::resetTextColor();
            std::cout << "1. Bus\n";
            std::cout << "2. Movie\n";
            std::cout << "3. Exit\n";
            std::cout << "\nEnter your choice: ";
            std::getline(std::cin, choice);
            if (choice == "1") {
                system("cls");
                BusInterface::adminBusMain();
            }

            else if (choice == "2") {
                system("cls");
                MovieInterface::adminMovieOptions();
            }

            else if (choice == "3") {
                Color::setLightMagentaTextColor();
                std::cout << "\nExiting Admin Interface....\n\n";
                Color::resetTextColor();
                system("pause");
                return;
            }
            else {
                Print::Error("Invalid Choice!");
                system("pause");
            }
        }
    }

    static void userInterface(const std::string& userName) {
        while (true) {
            system("cls");
            std::string choice;
            Color::setCyanTextColor();
            std::cout << "----------------------------------------------------\n";
            std::cout << "                  User Interface                    \n";
            std::cout << "----------------------------------------------------\n\n";
            Color::resetTextColor();

            std::cout << "1. Bus\n";
            std::cout << "2. Movie\n";
            std::cout << "3. Exit\n";
            std::cout << "\nEnter your choice: ";
            std::getline(std::cin, choice);
            if (choice == "1") {
                system("cls");
                BusInterface::userBusMain(userName);
            }

            else if (choice == "2") {
                system("cls");
                MovieInterface::userMovieOptions(userName);
            }

            else if (choice == "3") {
                Color::setLightMagentaTextColor();
                std::cout << "\nExiting User Interface....\n\n";
                Color::resetTextColor();
                system("pause");
                return;
            }
            else {
                Print::Error("Invalid Choice!");
                system("pause");
            }
        }
    }

    static void Main() {
        std::string choice;
        int max_try = 5, count = 0;
        int lock_count = 0, max_timer_limit = 2, timer = 30;

    MAIN_MENU:
        while (true) {
            system("cls");
            Menu::loginPage();
            if (lock_count >= max_timer_limit) {
                pause(3);
                Color::setRedTextColor();
                std::cout << "\nYou have exceeded the input limit.\n\nProgram terminated!\n";
                Color::resetTextColor();
                exit(1);
            }
            if (count >= max_try) {
                lock_count++;
                Color::setRedTextColor();
                std::cout << "\nYou have exceeded the number of tries!\n\nSystem locked!\n";
                Color::resetTextColor();
                pause(timer);
                count = 0;
                system("cls");
                Menu::loginPage();
            }

            std::cout << "\nEnter your choice: ";
            std::getline(std::cin, choice);

            if (choice == "1") {
                system("cls");
                Color::setCyanTextColor();
                std::cout << "----------------------------------------------------\n";
                std::cout << "                     User Login                     \n";
                std::cout << "----------------------------------------------------\n\n";
                Color::resetTextColor();

                std::string usernameOrContact;
                std::cout << "Enter Username / Email / Phone (type 'back' to return): ";
                std::getline(std::cin, usernameOrContact);

                if (usernameOrContact == "back")
                    goto MAIN_MENU;

                std::cout << "\nEnter Password: ";
                std::string password;
                char ch;
                while ((ch = _getch())) {
                    if (ch == '\r') {
                        std::cout << std::endl;
                        break;
                    }
                    else if (ch == '\b' && !password.empty()) { // Handle backspace
                        std::cout << "\b \b";
                        password.pop_back();
                    }
                    else {
                        password += ch;
                        std::cout << "*";
                    }
                }
                std::cout << "\n";

                Login loginObj;
                if (loginObj.login(usernameOrContact, password)) {
                    Color::setGreenTextColor();
                    std::cout << "Login Successful\n\n";
                    Color::resetTextColor();
                    system("pause");
                    userInterface(Validation::getUsernameFromFile(usernameOrContact));
                }
                else {
                    Color::setRedTextColor();
                    std::cout << "Error: Invalid credentials.\n\n";
                    Color::resetTextColor();
                    system("pause");
                }

            }

            else if (choice == "2") {
                system("cls");
                Login::signUp();
                continue;

            }

            else if (choice == "3") {
                system("cls");
                Color::setCyanTextColor();
                std::cout << "----------------------------------------------------\n";
                std::cout << "                    Admin Login                     \n";
                std::cout << "----------------------------------------------------\n\n";
                Color::resetTextColor();

                std::string usernameOrContact;
                std::cout << "Enter Username / Email / Phone (type 'back' to return): ";
                std::getline(std::cin, usernameOrContact);

                if (usernameOrContact == "back")
                    goto MAIN_MENU;

                std::cout << "\nEnter Password: ";
                std::string password;
                char ch;
                while ((ch = _getch()) != '\r') {  // Enter key
                    if (ch == '\b') {              // Backspace
                        if (!password.empty()) {
                            password.pop_back();
                            std::cout << "\b \b";
                        }
                    }
                    else {
                        password += ch;
                        std::cout << '*';
                    }
                }
                std::cout << "\n";
                Login loginObj;
                if (loginObj.adminLogin(usernameOrContact, password)) {
                    Color::setGreenTextColor();
                    std::cout << "Login Successful\n\n";
                    Color::resetTextColor();
                    system("pause");
                    adminInteface();
                }
                else {
                    Color::setRedTextColor();
                    std::cout << "Error: Invalid credentials.\n\n";
                    Color::resetTextColor();
                    system("pause");
                }
                continue;

            }
            else if (choice == "4") {
                Color::setLightMagentaTextColor();
                std::cout << "\nExiting System......\n\n";
                Color::resetTextColor();
                system("pause");
                TicketNexusAnimation();
                exit(1);

            }
            else {
                count++;
                Color::setRedTextColor();
                std::cout << "Error: Invalid menu option.\n";
                Color::resetTextColor();
                system("pause");
            }
        }
    }
};

int main() {
    TicketNexusAnimation();
    system("pause");

    Interface::Main();
    return 0;
}