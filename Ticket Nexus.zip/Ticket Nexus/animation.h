#include<iostream>
#include <windows.h>

void jaadu() {
    HANDLE hInput = GetStdHandle(STD_INPUT_HANDLE);
    HANDLE hOutput = GetStdHandle(STD_OUTPUT_HANDLE);

    // Hide cursor
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(hOutput, &cursorInfo);
    cursorInfo.bVisible = FALSE;
    SetConsoleCursorInfo(hOutput, &cursorInfo);
    // Countdown display (optional)

	 Sleep(230); // can be incresed or decreased for altering speed  
	 
    // Flush any existing input (keyboard buffer)
    FlushConsoleInputBuffer(hInput);

    // Show cursor again
    cursorInfo.bVisible = TRUE;
    SetConsoleCursorInfo(hOutput, &cursorInfo);
	
}

void TicketNexusAnimation(){
	system("cls");
	std::cout <<"\n\n\n\n\n\n";																Color::setCyanTextColor();
	std::cout <<"========  ========  ======  ||   //  ||======   ========";				Color::setLightMagentaTextColor();		std::cout<<"    ||\\\\     ||  ||======    \\\\    //   ||      ||  ||========\n";		Color::setLightCyanTextColor();	jaadu();
	std::cout <<"   ||        ||     ||      ||  //   ||            ||   "; 				Color::setLightMagentaTextColor();		std::cout<<"    || \\\\    ||  ||           \\\\  //    ||      ||  ||\n";		Color::setCyanTextColor();jaadu();
	std::cout <<"   ||        ||     ||      ||_//    ||______      ||   ";				Color::setLightMagentaTextColor();		std::cout<<"    ||  \\\\   ||  ||______      \\\\//     ||      ||  ||\n";		Color::setCyanTextColor();	jaadu();
	std::cout <<"   ||        ||     ||      || \\\\    ||            ||  ";				Color::setLightMagentaTextColor();		std::cout<<"     ||   \\\\  ||  ||            //\\\\     ||      ||  ========||\n";		Color::setCyanTextColor();	jaadu();
	std::cout <<"   ||        ||     ||      ||  \\\\   ||            ||  ";				Color::setLightMagentaTextColor();		std::cout<<"     ||    \\\\ ||  ||           //  \\\\    ||      ||          ||\n";		Color::setCyanTextColor();	jaadu();
	std::cout <<"   ||     ========  ======  ||   \\\\  ||______      ||  ";				Color::setLightMagentaTextColor();		std::cout<<"     ||     \\\\||  ||______    //    \\\\   ||______||  ________||\n";		Color::resetTextColor();
	
	
	std::cout <<"\n\n\n\n\n";
	
}
