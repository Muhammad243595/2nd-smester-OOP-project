#include <iostream>
#include <string>
#include <fstream>
#include <windows.h>
#include <ctime>
#include <sstream>
#include <conio.h>
#include <iomanip>
#include "Color.h"

class Print {
public:
    static void Error(const std::string& msg) {
        Color::setRedTextColor();
        std::cout << "Error: " << msg << "\n\n";
        Color::resetTextColor();
    }

    static void Warning(const std::string& msg) {
        Color::setYellowTextColor();
        std::cout << "Warning: " << msg << "\n\n";
        Color::resetTextColor();
    }

    static void Success(const std::string& msg) {
        Color::setGreenTextColor();
        std::cout << "Success: " << msg << "\n\n";
        Color::resetTextColor();
    }

    static void Saved() {
        Color::setGreenTextColor();
        std::cout << "Saved\n\n";
        Color::resetTextColor();
    }
};

struct BusRecord {
    //Bus Data
    std::string busID;
    std::string numberPlate;
    std::string type;
    std::string totalSeat;
    int numberOfAvailableSeats = 0;
    std::string fare;
    //Bus Driver Data
    std::string driverID;
    std::string driverName;
    std::string driverAge;
    std::string driverPhoneNumber;
    //Bus Departure Schedule
    std::string departureCity;
    std::string departureDate;
    std::string departureTime;
    //Bus Arrival Schedule
    std::string arrivalCity;
    std::string arrivalDate;
    std::string arrivalTime;
};

struct BusTicketRecord {
    std::string username;
    std::string busID;
    std::string seatNumber;
    std::string fare;
    std::string departureCity;
    std::string departureDate;
    std::string departureTime;
    std::string arrivalCity;
    std::string arrivalDate;
    std::string arrivalTime;
    std::string bookingTime;
};

struct MovieTicketRecord {
    std::string username = "";
    std::string ID = "";
    std::string title = "";
    std::string genre = "";
    std::string duration = "";
    std::string date = "";
    std::string time = "";
    std::string rating = "";
    std::string cinemaName = "";
    std::string screenNumber = "";
};

struct UserRecord {
    std::string firstName;
    std::string lastName;
    std::string username;
    std::string emailAddress;
    std::string phoneNumber;
    std::string password;
};

struct MovieRecord {
    std::string ID = "";
    std::string title = "";
    std::string genre= "";
    std::string duration = "";
    std::string date = "";
    std::string time = "";
    std::string rating = "";
    std::string cinemaName = "";
    std::string screenNumber = "";
};

class Validation {
public:
    static bool isValidInteger(const std::string& temp, const std::string prompt) {
        try {
            int value = std::stoi(temp);
            return true;
        }
        catch (const std::out_of_range&) {
            Print::Error(prompt + " is out of range.");
            return false;
        }
    }

    static bool isValidFloat(const std::string& temp, const std::string prompt) {
        try {
            float value = std::stof(temp);
            return true;
        }
        catch (const std::out_of_range&) {
            Print::Error(prompt + " is out of range.");
            return false;
        }
    }

    static bool isEmpty(const std::string& temp, const std::string& stringValue) {
        if (temp.empty()) {
            Print::Error(stringValue + " cannot be empty.");
            return true;
        }
        else
            return false;
    }
	
    static std::string replaceSpaces(const std::string& input) {
        std::string result;
        bool previousWasSpace = false;

        for (char ch : input) {
            if (ch == ' ') {
                if (!previousWasSpace) {
                    result += '_';  // Replace first space in sequence with underscore
                }
                previousWasSpace = true;
            }
            else {
                result += ch;
                previousWasSpace = false;
            }
        }
        return result;
    }
    
    static std::string replaceUnderscores(const std::string& input) {
    		std::string result = input;

    		for (char& ch : result) {
        		if (ch == '_') {
            	ch = ' ';
        	}
    	}

    	return result;
	}

    static bool isContainingSpaces(const char& ch, const std::string& stringValue) {
        if (ch == ' ') {
            Print::Error(stringValue + " must not contain spaces.");
            return true;
        }
        else
            return false;
    }

    static bool isValidScreenNumber(const std::string& temp) {
        if (isEmpty(temp, "Screen number"))
            return false;
        for (char ch : temp) {
            if (isContainingSpaces(ch, "Screen number"))
                return false;
            else if (isalpha(ch)) {
                Color::setRedTextColor();
                std::cout << "Error: Screen number must not contain letters.\n\n";
                Color::resetTextColor();
                return false;
            }
            else if (!isdigit(ch)) {
                Color::setRedTextColor();
                std::cout << "Error: Screen number must not contain special characters.\n\n";
                Color::resetTextColor();
                return false;
            }
        }
        if (temp.length() > 2) {
            Color::setRedTextColor();
            std::cout << "Error: Screen number is very large.\n\n";
            Color::resetTextColor();
            return false;
        }
        int ScreenNumber = stoi(temp);
        if (ScreenNumber < 0 || ScreenNumber>50) {
            Color::setRedTextColor();
            std::cout << "Error: Screen number must be between 1-50.\n\n";
            Color::resetTextColor();
            return false;
        }
        return true;

    }

    static void getCurrentTime(tm& localTime) {
        std::time_t nowTime = std::time(0);
        localtime_s(&localTime, &nowTime);
    }

    static bool isValidName(const std::string& temp, const std::string& prompt) {
        if (isEmpty(temp, prompt))
            return false;

        if (temp.length() > 100) {
            Print::Error(prompt + " cannot exceed 100 characters.");
            return false;
        }

        if (temp.length() < 2) {
            Print::Error("Invalid " + prompt + ".");
            return false;
        }

        for (char ch : temp) {
            if (isdigit(ch)) {
                Print::Error(prompt + " must not contain digits.");
                return false;
            }
            else if (!isalpha(ch) && ch != ' ') {
                Print::Error(prompt + " must not contain special characters.");
                return false;
            }
        }
        return true;
    }

    static bool isValidEmail(const std::string& temp) {
        if (isEmpty(temp, "Email address"))
            return false;

        if (temp.length() > 320) {
            Print::Error("Email address exceeds the maximum allowed length (320 characters).");
            return false;
        }
        if (temp.length() < 6) {
            Print::Error("Invalid email format. Expected format : example@domain.com");
            return false;
        }
        short atTheRateOfCounter = 0, periodCounter = 0;
        for (char ch : temp) {
            if (isContainingSpaces(ch, "Email Address"))
                return false;
            else if (ch == '@')
                atTheRateOfCounter++;
            else if (ch == '.')
                periodCounter++;
        }
        if (atTheRateOfCounter != 1 && periodCounter != 1) {
            Print::Error("Invalid email format. Expected format : example@domain.com");
            return false;
        }

        else if (temp.front() == '@' || temp.back() == '.') {
            Print::Error("Invalid email format. Expected format : example@domain.com");
            return false;
        }
        else if (!(temp.back() == 'm' && temp[temp.length() - 2] == 'o' && temp[temp.length() - 3] == 'c' && temp[temp.length() - 4] == '.')) {
            Print::Error("Invalid email format. Expected format : example@domain.com");
            return false;
        }

        return true;
    }

    static bool isUserDuplicateData(const std::string& temp) {
        std::ifstream read("UserData.txt");
        std::string line = "";
        UserRecord record;
        while (getline(read, line)) {
            std::istringstream in(line);
            getline(in, record.username, '|');
            getline(in, record.password, '|');
            getline(in, record.firstName, '|');
            getline(in, record.lastName, '|');
            getline(in, record.emailAddress, '|');
            getline(in, record.phoneNumber);
            //for validating duplicate usernames
            if (temp == record.username) {
                Print::Error("Username already exist.");
                return false;
            }
            //for validating duplicate emails
            else if (temp == record.emailAddress) {
                Print::Error("Email already exist.");
                return false;
            }
            //for validating duplicate phone No
            else if (temp == record.phoneNumber) {
                Print::Error("Phone Number already exist.");
                return false;
            }
        }
        return true;
    }
    
    static std::string getUsernameFromFile(const std::string& temp) {
        std::ifstream read("UserData.txt");
        std::string line = "";
        UserRecord record;
        while (getline(read, line)) {
            std::istringstream in(line);
            getline(in, record.username, '|');
            getline(in, record.password, '|');
            getline(in, record.firstName, '|');
            getline(in, record.lastName, '|');
            getline(in, record.emailAddress, '|');
            getline(in, record.phoneNumber);
            //for validating duplicate usernames
            if (temp == record.username || temp == record.emailAddress || temp == record.phoneNumber) {
                return record.username;
            }
        }
        return "";
    }

    static bool isValidPhoneNumber(const std::string& temp, const std::string& prompt) {
        if (isEmpty(temp, prompt))
            return false;
        if (temp == "00000000000") {
            Print::Error(prompt + " can not be " + temp);
            return false;
        }
        for (char ch : temp) {
            if (isContainingSpaces(ch, prompt))
                return false;

            else if (isalpha(ch)) {
                Print::Error(prompt + " must not contain letters.");
                return false;
            }
            else if (!isdigit(ch)) {
                Print::Error(prompt + " must not contain special characters.");
                return false;
            }
        }

        if (temp.length() != 11) {
            Print::Error(prompt + " must be exactly 11 digits.");
            return false;
        }
        return true;
    }

    static bool isValidUsername(const std::string& temp) {
        if (isEmpty(temp, "Username"))
            return false;

        for (char ch : temp) {
            if (isContainingSpaces(ch, "Username"))
                return false;
        }
        if ((isalpha(temp.front())) && (temp.back() == '_' || isalpha(temp.back()) || isdigit(temp.back()))) {
            return true;
        }

        else {
            Print::Error("Username cannot start or end with special charectors.");
            return false;
        }
        for (size_t i = 0; i < temp.size(); ++i) {
            char ch = temp[i];

            // Optionally, you can check for spaces too.
            if (isspace(ch)) {
                Print::Error("Username cannot contain spaces.");
                return false;
            }

            // For the first and last characters, you've already validated,
            // so now check only the middle ones.
            if (i != 0 && i != temp.size() - 1) {
                if (!(isalpha(ch) || isdigit(ch) || ch == '_')) {
                    Print::Error("Username can contain only letters, digits, or underscores in the middle.");
                    return false;
                }
            }
        }
        return true;
    }

    static bool isValidPassword(const std::string& temp) {
        if (isEmpty(temp, "Password"))
            return false;

        if (temp.length() < 8) {
            Print::Error("Password must be atleast 8 characters.");
            return false;
        }

        if (temp.length() > 40) {
            Print::Error("Password cannot exceed 40 characters.");
            return false;
        }

        bool checkContain = true;


        for (char ch : temp) {
            if (isalpha(ch)) {
                checkContain = false;
            }
        }

        if (checkContain) {
            Print::Error("Password must contain characters.");
            return false;
        }
        for (char ch : temp) {
            if (isContainingSpaces(ch, "Password"))
                return false;
        }

        checkContain = true;

        for (char ch : temp) {
            if (isdigit(ch)) {
                checkContain = false;
            }
        }

        if (checkContain) {
            Print::Error("Password must contain atleast 1 digit.");
            return false;
        }

        checkContain = true;
        for (char ch : temp) {
            if (!isdigit(ch) and !isalpha(ch)) {
                checkContain = false;
            }
        }


        if (checkContain) {
            Print::Error("Password must contain atleast 1 special characters.");
            return false;
        }
        return true;
    }

    static bool isValidCardNumber(const std::string& temp) {
        if (isEmpty(temp, "Card Number"))
            return false;

        for (char ch : temp) {
            if (isContainingSpaces(ch, "Card Number"))
                return false;

            else if (isalpha(ch)) {
                Print::Error("Card Number must not contain letters.");
                return false;
            }
            else if (!isdigit(ch)) {
                Print::Error("Card Number must not contain special characters.");
                return false;
            }
        }

        if (temp.length() != 16) {
            Print::Error("Card Number must be exactly 16 digits.");
            return false;
        }
        return true;
    }

    static bool isValidDateFormat(const std::string& temp, const std::string& prompt) {
        if (isEmpty(temp, prompt))
            return false;

        for (char ch : temp) {
            if (isContainingSpaces(ch, prompt))
                return false;

            else if (isalpha(ch)) {
                Print::Error(prompt + " must not contain letters.");
                return false;
            }
        }

        if (temp.length() != 10) {
            Print::Error(prompt + " must follow proper format (dd/mm/yyyy).");
            return false;
        }

        if (temp[2] != '/' || temp[5] != '/') {
            Print::Error(prompt + " must follow proper format (dd/mm/yyyy).");
            return false;
        }
        return true;
    }

    static bool isValidDate(const std::string& temp, const std::string& prompt) {
        if (!isValidDateFormat(temp, prompt))
            return false;

        // Extract day, month, and year from the input string
        int date = std::stoi(temp.substr(0, 2));
        int month = std::stoi(temp.substr(3, 2));
        int year = std::stoi(temp.substr(6, 4));

        std::tm localTime;
        getCurrentTime(localTime);
        int currentYear = localTime.tm_year + 1900;
        int currentMonth = localTime.tm_mon + 1;
        int currentDate = localTime.tm_mday;

        // Validate the month range
        if (month < 1 || month > 12) {
            Print::Error("Invalid Month.");
            return false;
        }

        // Enforce that the year matches the current year
        if (year != currentYear) {
            Print::Error(prompt + " Current Year is " + std::to_string(currentYear) +
                ", It's not " + std::to_string(year) + ".");
            return false;
        }

        // Determine the maximum valid day count for the given month, considering leap years
        int daysInMonth[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
        if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
            daysInMonth[1] = 29;  // Adjust February days in leap years
        }

        // Validate that the day falls in the acceptable range for this month
        if (date <= 0 || date > daysInMonth[month - 1]) {
            Print::Error("Invalid Date.");
            return false;
        }

        // Ensure the date is not in the past: it must be today or in the future.
        if (month < currentMonth || (month == currentMonth && date < currentDate)) {
            Print::Error(prompt + " must be today or in the future.");
            return false;
        }

        return true;
    }

    static bool isValidCVV(const std::string& temp) {
        if (isEmpty(temp, "CVV"))
            return false;

        for (char ch : temp) {
            if (isContainingSpaces(ch, "CVV"))
                return false;

            else if (isalpha(ch)) {
                Print::Error("CVV must not contain letters.");
                return false;
            }
            else if (!isdigit(ch)) {
                Print::Error("CVV must not contain special characters.");
                return false;
            }
        }

        if (temp.length() != 3 && temp.length() != 4) {
            Print::Error("CVV must be exactly 3 or 4 digits.");
            return false;
        }
        return true;
    }

    static bool isValidTimeFormat(const std::string& time, const std::string& prompt) {
        if (isEmpty(time, prompt))
            return false;

        for (char ch : time) {
            if (isContainingSpaces(ch, prompt))
                return false;
        }
        if (time.length() != 5 || time[2] != ':') {
            Print::Error(prompt + " must be in HH : MM(24 - hour format).");
            return false;
        }

        std::string hoursStr = time.substr(0, 2);
        std::string minutesStr = time.substr(3, 2);

        if (!isdigit(hoursStr[0]) || !isdigit(hoursStr[1]) ||
            !isdigit(minutesStr[0]) || !isdigit(minutesStr[1])) {
            Print::Error(prompt + " must only contain numeric values.");
            return false;
        }

        int hours = std::stoi(hoursStr);
        int minutes = std::stoi(minutesStr);

        if (hours < 0 || hours > 23) {
            Print::Error("Hours must be between 00 and 23.");
            return false;
        }

        if (minutes < 0 || minutes > 59) {
            Print::Error("Minutes must be between 00 and 59.");
            return false;
        }
        return true;
    }

    static bool isValidNumberPlate(const std::string& plate) {
        if (isEmpty(plate, "Number Plate"))
            return false;

        if (plate.length() != 6) {
            Print::Error(" Number Plate must be exactly of 6 characters.");
            return false;
        }
        if (!isalpha(plate[0]) || !isalpha(plate[1]) || !isalpha(plate[2]) ||
            !isdigit(plate[3]) || !isdigit(plate[4]) || !isdigit(plate[5])) {
            Print::Error(": Number Plate must match the format AAA000.");
            return false;
        }

        return true;
    }

    static bool isValidAge(const std::string& age) {
        if (isEmpty(age, "Age"))
            return false;

        for (char ch : age) {
            if (isContainingSpaces(ch, "Age"))
                return false;

            if (isalpha(ch)) {
                Print::Error(" Age must not contain alphabets.");
                return false;
            }
            if (!isdigit(ch)) {
                Print::Error(" Age must not contain special characters.");
                return false;
            }
        }
        if (!isValidInteger(age, "Age")) return false;
        int Age = std::stoi(age);
        if (Age < 18 || Age > 75) {
            Print::Error("Age must be in between 18 and 75");
            return false;
        }
        return true;
    }

    static bool isValidCity(const std::string& city, const std::string& prompt) {
        if (isEmpty(city, prompt))
            return false;
        else if (city[0] == ' ') {
            Print::Error(prompt + " can not be empty.");
            return false;
        }
        for (char ch : city) {
            if (isdigit(ch)) {
                Print::Error(prompt + " must not contain digits.");
                return false;
            }
            if (!isalpha(ch) && ch != ' ') {
                Print::Error(prompt + " must not contain special characters.");
                return false;
            }
        }
        return true;
    }

    static bool isValidSeatNumber(const std::string& seats, const std::string& prompt) {
        if (isEmpty(seats, prompt))
            return false;

        for (const char ch : seats) {
            if (isContainingSpaces(ch, prompt))
                return false;

            if (isalpha(ch)) {
                Print::Error(prompt + " must not contain alphabets.");
                return false;
            }
            if (!isdigit(ch)) {
                Print::Error(prompt + " must not contain special characters.");
                return false;
            }
        }
        return true;
    }

    static void redefineBusSeatFile(const std::string& busID, const std::string& totalSeat) {
        std::ifstream readSeatData("Bus_" + busID + "_Seats.txt");
        if (readSeatData.fail()) {
            Print::Error("Unable to open Bus_" + busID + "_Seats File.");
            return;
        }
        int totSeat = std::stoi(totalSeat);
        bool* availSeat = new bool[totSeat]();
        int status = -1;
        for (int i = 0; i < totSeat; i++) {
            readSeatData >> status;
            if (status == 1)
                availSeat[i] = true;
            else
                availSeat[i] = false;
        }
        readSeatData.close();
        std::ofstream writeSeatData("Bus_" + busID + "_Seats.txt", std::ios::trunc);
        if (writeSeatData.fail()) {
            Print::Error("Unable to open Bus_" + busID + "_Seats File.");
            delete[] availSeat;
            return;
        }
        
        for (int i = 0; i < totSeat; i++) {
            writeSeatData << ((availSeat[i]) ? "1" : "0") << "\n";
        }
        delete[] availSeat;
        return;
    }

    static bool isValidBusSeatAccordingToType(const std::string& seat, const std::string& prompt, const std::string type) {
        if (!isValidSeatNumber(seat, prompt)) return false;

        else if (!isValidInteger(seat, prompt)) return false;

        int totalSeats = std::stoi(seat);
        if (type == "Economy" && (totalSeats < 40 || totalSeats > 50)) {
            Print::Error(prompt + " must be in between 40 and 50 for Economy Class.");
            return false;
        }
        else if (type == "Business" && (totalSeats < 30 || totalSeats > 40)) {
            Print::Error(prompt + " must be in between 30 and 40 for Business Class.");
            return false;
        }
        else if (type == "Executive" && (totalSeats < 25 || totalSeats > 35)) {
            Print::Error(prompt + " must be in between 25 and 35 for Executive Class.");
            return false;
        }
        else if (type == "Sleeper" && (totalSeats < 20 || totalSeats > 30)) {
            Print::Error(prompt + " must be in between 20 and 30 for Sleeper Class.");
            return false;
        }
        else if (type == "VIP" && (totalSeats < 15 || totalSeats > 25)) {
            Print::Error(prompt + " must be in between 15 and 25 for VIP Class.");
            return false;
        }
        return true;
    }
    
    static bool isValidID(const std::string& ID, const std::string& prompt) {
        if (isEmpty(ID, prompt)) return false;

        for (const char ch : ID) {
            if (isalpha(ch)) {
                Print::Error(prompt + " must not contain alphabets.");
                return false;
            }
            if (!isdigit(ch)) {
                Print::Error(prompt + " must not contain special characters.");
                return false;
            }
        }

        if (!isValidInteger(ID, prompt)) return false;

        return true;
    }

    static bool isValidPrice(const std::string& price, const std::string& prompt) {
        if (isEmpty(price, prompt))
            return false;
        if (price.front() == '.') {
            Print::Error(prompt + " must not start with a decimal point.");
            return false;
        }
        else if (price.back() == '.') {
            Print::Error(prompt + " must not end with a decimal point.");
            return false;
        }

        short dot_count = 0, precision_count = 0;
        
        for (const char ch : price) {
            if (isContainingSpaces(ch, prompt))
                return false;

            if (ch == '.') {
                dot_count++;
            }

            if (dot_count > 1) {
                Print::Error(prompt + " must not have multiple '.' signs.");
                return false;
            }

            if (dot_count == 1 && isdigit(ch)) {
                precision_count++;
            }

            if (precision_count > 2) {
                Print::Error(prompt + " must not exceed two decimal places.");
                return false;
            }

            if (isalpha(ch)) {
                Print::Error(prompt + " must not contain alphabets.");
                return false;
            }

            if (!isdigit(ch) && ch != '.') {
                Print::Error(prompt + " must not contain special characters except '.'.");
                return false;
            }
        }
        if (isValidFloat(price, prompt)) return true;
        return true;
    }

    static bool isValidBusPriceAccordingToType(const std::string& price, const std::string& prompt, const std::string& type) {
        if (!isValidPrice(price, prompt)) return false;

        else if (!isValidFloat(price, prompt)) return false;

        float fare = std::stof(price);
        if (type == "Economy" && (fare < 3.5 || fare > 10)) {
            Print::Error(prompt + " must be in between $3.50 and $10.0 for Economy Class.");
            return false;
        }
        else if (type == "Business" && (fare < 7 || fare > 18)) {
            Print::Error(prompt + " must be in between $7.0 and $18.0 for Business Class.");
            return false;
        }
        else if (type == "Executive" && (fare < 10 || fare > 25)) {
            Print::Error(prompt + " must be in between $10.0 and $25.0 for Executive Class.");
            return false;
        }
        else if (type == "Sleeper" && (fare < 15 || fare > 35)) {
            Print::Error(prompt + " must be in between $15.0 and $35.0 for Sleeper Class.");
            return false;
        }
        else if (type == "VIP" && (fare < 20 || fare > 40)) {
            Print::Error(prompt + " must be in between $20.0 and $40.0 for VIP Class.");
            return false;
        }
        return true;
    }

    static bool isValidBusType(const std::string& busType, const std::string& prompt) {
        if (Validation::isEmpty(busType, prompt))
            return false;

        for (const char ch : busType) {
            if (isContainingSpaces(ch, prompt)) {
                return false;
            }
            if (isdigit(ch)) {
                Print::Error(prompt + " must not contain digits.");
                return false;
            }
            if (!isalpha(ch)) {
                Print::Error(prompt + " must not contain special characters.");
                return false;
            }
        }
        std::string validTypes[] = { "Economy", "Business", "Executive", "Sleeper", "VIP" };
        for (const std::string& typeOption : validTypes) {
            if (busType == typeOption) {
                return true;
            }
        }
        Print::Error(prompt + " is Invalid.");
        return false;
    }

    static bool isFileEmpty(std::ifstream& read, const std::string& prompt) {
        if (read.peek() == std::ifstream::traits_type::eof()) {
            Print::Error(prompt + " File is empty.");
            return true;
        }
        else
            return false;
    }
    
    //Choice Checks 1 = Bus ID, 2 = Number Plate, 3 = Driver ID
    static bool doesDataExistInBusFile(const std::string& inputData, const char& choice) {
        std::ifstream read("Bus_Data.txt");
        if (read.fail()) {
            return false;
        }
        else if (read.peek() == std::ifstream::traits_type::eof()) {
            return false;
        }
        BusRecord record;
        std::string line = "";
        /*
        Saving Format
        0.Bus ID(int) 1.Number Plate(string) 2.Type(string) 3.Total Seat(int) 4.Fare(float)
        5.Driver ID(int) 6.Driver Name(string) 7.Driver Age(int) 8. Driver Phone Number(string)
        9.Departure City(string) 10.Departure Date(string) 11.Departure Time(string)
        12.Arrival City(string) 13. Arrival Date(string) 14. Arrival Time(string)
        */
        while (getline(read, line)) {
            std::istringstream in(line);
            getline(in, record.busID, '|');
            getline(in, record.numberPlate, '|');
            getline(in, record.type, '|');
            getline(in, record.totalSeat, '|');
            getline(in, record.fare, '|');

            getline(in, record.driverID, '|');
            getline(in, record.driverName, '|');
            getline(in, record.driverAge, '|');
            getline(in, record.driverPhoneNumber, '|');

            getline(in, record.departureCity, '|');
            getline(in, record.departureDate, '|');
            getline(in, record.departureTime, '|');

            getline(in, record.arrivalCity, '|');
            getline(in, record.arrivalDate, '|');
            getline(in, record.arrivalTime);
            switch (choice) {
            case '1': {             //Bus ID
                if (record.busID == inputData) {
                    return true;
                }
            }
            case '2': {             //Number Plate
                if (record.numberPlate == inputData) {
                    return true;
                }
            }
            case '3': {             //Driver ID
                if (record.driverID == inputData) {
                    return true;
                }
            }
            }
        }
        return false;
    }

    static bool isValidTime(const std::string time, const std::string date, const std::string prompt) {
        if (!isValidTimeFormat(time, prompt)) return false;
        int departureDate = std::stoi(date.substr(0, 2));
        int departureMonth = std::stoi(date.substr(3, 2));
        int hours = std::stoi(time.substr(0, 2));
        int minutes = std::stoi(time.substr(3, 2));
        tm localTime;
        getCurrentTime(localTime);
        int currentDate = localTime.tm_mday;
        int currentMonth = localTime.tm_mon + 1;
        int currentHour = localTime.tm_hour;
        int currentMinute = localTime.tm_min;

        if ((departureDate == currentDate && departureMonth == currentMonth) && (hours < currentHour || (hours == currentHour && minutes <= currentMinute))) {
            Print::Error(prompt + " must be ahead of current time.");
            return false;
        }
        return true;
    }

    static bool isValidArrivalDate(const std::string& arrivalDates, const std::string& departureDates) {
        if (!isValidDateFormat(arrivalDates, "Arrival Date")) return false;

        if (!isValidDate(arrivalDates, "Arrival Date")) return false;

        int arrivalDate = std::stoi(arrivalDates.substr(0, 2));
        int arrivalMonth = std::stoi(arrivalDates.substr(3, 2));

        int departureDate = std::stoi(departureDates.substr(0, 2));
        int departureMonth = std::stoi(departureDates.substr(3, 2));

        if (arrivalMonth < departureMonth || (arrivalMonth == departureMonth && arrivalDate < departureDate)) {
            Print::Error("Arrival Date must be ahead of Departure Date.");
            return false;
        }
        else if ((arrivalDate > departureDate + 2 && arrivalMonth == departureMonth) || (arrivalMonth > departureMonth)) {
            Print::Error("Arrival Date can not be more than 2 days of Departure Date.");
            return false;
        }
        return true;
    }

    static bool isValidArrivalTime(const std::string& arrivalTime, const std::string& departureTime, const std::string& arrivalDates, const std::string& departureDates) {
        if (!isValidTimeFormat(arrivalTime, "Arrival Time")) return false;
        
        //Converting Arrival Time String to Int
        int hours = std::stoi(arrivalTime.substr(0, 2));
        int minutes = std::stoi(arrivalTime.substr(3, 2));

        //Converting Departure Time String to Int
        int departureHours = std::stoi(departureTime.substr(0, 2));
        int departureMinutes = std::stoi(departureTime.substr(3, 2));

        //Converting Arrival Date and Month to Int
        int arrivalDate = std::stoi(arrivalDates.substr(0, 2));
        int arrivalMonth = std::stoi(arrivalDates.substr(3, 2));

        //Converting Departure Date and Month to Int
        int departureDate = std::stoi(departureDates.substr(0, 2));
        int departureMonth = std::stoi(departureDates.substr(3, 2));

        if (arrivalDate == departureDate && arrivalMonth == departureMonth) {
            if (hours < departureHours || (hours == departureHours && minutes <= departureMinutes)) {
                Print::Error("Arrival Time must be ahead of Departure Time.");
                return false;
            }
        }
        if ((arrivalDate > departureDate && arrivalDate < departureDate + 3) && arrivalMonth == departureMonth) {
            return true;
        }

        return true;
    }

};
