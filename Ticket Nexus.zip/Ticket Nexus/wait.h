#include <iostream>
#include <thread>
#include <windows.h>

void pause(int seconds) {
    HANDLE hInput = GetStdHandle(STD_INPUT_HANDLE);
    HANDLE hOutput = GetStdHandle(STD_OUTPUT_HANDLE);

    // Hide cursor
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(hOutput, &cursorInfo);
    cursorInfo.bVisible = FALSE;
    SetConsoleCursorInfo(hOutput, &cursorInfo);
	std::cout << "\a";
    // Countdown display (optional)
    for (int i = seconds; i > 0; --i) {
        std::cout << "\rPlease wait " << i << " seconds...   " << std::flush;
        Sleep(1000);
	}
	std::cout<<std::endl;
	
    // Flush any existing input (keyboard buffer)
    FlushConsoleInputBuffer(hInput);

    // Show cursor again
    cursorInfo.bVisible = TRUE;
    SetConsoleCursorInfo(hOutput, &cursorInfo);
	
}





